<?php
print "<div style=\"background-color: red; width: 100px; height: 100px; margin: 5px;\"></div>";
