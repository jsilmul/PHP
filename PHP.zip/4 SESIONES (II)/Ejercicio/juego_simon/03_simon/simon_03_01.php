<?php
session_name("simonparte3");
session_start();

$secuencia = rand(2, 7);
$colores = ["red", "yellow", "blue", "green"];

if (!isset($_SESSION["result"]) || !isset($_SESSION["tiradas"]) || !isset($_SESSION["exito"]) || !isset($_SESSION["error"])) {
    
    for ($i = 0; $i < $secuencia; $i++) {
        $_SESSION["result"][] = $colores[array_rand($colores)];
    }
    
    $_SESSION["tiradas"] = [];
    $_SESSION["exito"] = false;
    $_SESSION["error"] = false;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simón 03 - Separar lista de colores
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

  <h1>Simón 03 - Separar listas de colores</h1>

    <p>● En la primera página se muestra la lista de colores a reproducir. Para pasar a la  segunda página y empezar el juego, 
        se debe hacer clic en un botón.</p>
    <p>● En la segunda página el usuario va creando la lista de colores, con llamadas a la tercera página, y se indica si se ha 
        equivocado o ha completado la lista correcta.</p>
    <p>● En la tercera página se recibe el dato y se redirecciona a la segunda página.</p>

    <p>Secuencia a reproducir:</p>

    <div style="display: flex;">

      <?php
        foreach ($_SESSION["result"] as $color) {
            echo "<svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" style=\"margin-left:5px; background-color: $color\">";
            echo "</svg>";
        }
      ?>

    </div>


  <form action="simon_03_02.php" method="post">

    <p>Haga clic para comenzar el juego:</p>

    <p><input type="submit" name="eleccion" value="comenzar"></p>

  </form>

</body>

</html>