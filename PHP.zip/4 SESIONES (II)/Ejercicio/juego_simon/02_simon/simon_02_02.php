<?php
session_name("simonparte2");
session_start();

if (!isset($_SESSION["tiradas"])) {
    header("Location:simon_02_01.php");
    exit;
}

function recoge($variable, $color = ""){
    $variableTemporal = is_array($color) ? [] : "";
    if (isset($_REQUEST[$variable])) {
        if (!is_array($_REQUEST[$variable]) && !is_array($color)) {
            $variableTemporal = trim(htmlspecialchars($_REQUEST[$variable]));
        } elseif (is_array($_REQUEST[$variable]) && is_array($color)) {
            $variableTemporal = $_REQUEST[$variable];
            array_walk_recursive($variableTemporal, function (&$valor) {
                $valor = trim(htmlspecialchars($valor));
            });
        }
    }
    return $variableTemporal;
}

$eleccion = recoge("eleccion");
if ($eleccion == "reiniciar") {
    session_destroy();
}

if ($_SESSION["exito"] || $_SESSION["error"]) {
    header("Location:simon_02_01.php");
    exit;
}


if (in_array($eleccion, ["red", "yellow", "blue", "green"])) {
    $_SESSION["tiradas"][] = $eleccion;
    $_SESSION["error"] = false;
    for ($i = 0; $i < count($_SESSION["tiradas"]); $i++) {
        if ($_SESSION["tiradas"][$i] != $_SESSION["result"][$i]) {
            $_SESSION["error"] = true;
        }
    }
    if (!$_SESSION["error"] && count($_SESSION["tiradas"]) == count($_SESSION["result"])) {
        $_SESSION["exito"] = true;
    }
}

header("Location:simon_02_01.php");
?>