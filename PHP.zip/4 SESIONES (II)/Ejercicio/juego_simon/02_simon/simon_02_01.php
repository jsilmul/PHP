<?php
session_name("simonparte2");
session_start();

$secuencia = rand(2, 7);
$colores = ["red", "yellow", "blue", "green"];

if (!isset($_SESSION["result"]) || !isset($_SESSION["tiradas"]) || !isset($_SESSION["exito"]) || !isset($_SESSION["error"])) {
    
    for ($i = 0; $i < $secuencia; $i++) {
        $_SESSION["result"][] = $colores[array_rand($colores)];
    }
    
    $_SESSION["tiradas"] = [];
    $_SESSION["exito"] = false;
    $_SESSION["error"] = false;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simón 02 - Comprobar lista de colores
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

  <h1>Simón 02 - Comprobar lista de colores</h1>

  <p>● Muestra una lista de entre 2 y 7 colores, al azar. Indica si la lista de colores creada coincide con la propuesta. En cuanto el usuario se equivoca, el juego termina.</p>

  <p>Secuencia a reproducir:</p>

  <div style="display: flex;">

    <?php
      foreach ($_SESSION["result"] as $color) {
          echo "<svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" style=\"margin-left:5px; background-color: $color\">";
          echo "</svg>";
      }
    ?>

  </div>

  <form action="simon_02_02.php" method="post">

      <p>Haga clic en los colores:</p>

        <table>
          <tbody>
            <tr>
              <td>
                <button type="submit" name="eleccion" value="red">
                  <div style="background-color: red; width: 60px; height: 60px"></div>
                </button>
              </td>
              <td>
                <button type="submit" name="eleccion" value="yellow">
                  <div style="background-color: yellow; width: 60px; height: 60px"></div>
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <button type="submit" name="eleccion" value="blue">
                  <div style="background-color: blue; width: 60px; height: 60px"></div>
                </button>
              </td>
              <td>
                <button type="submit" name="eleccion" value="green">
                  <div style="background-color: green; width: 60px; height: 60px"></div>
                </button>
              </td>
            </tr>
          </tbody>
        </table>

      <p><input type="submit" name="eleccion" value="reiniciar"></p>

  </form>

  <p>Colores elegidos:</p>
  
  <div style="display: flex;">

      <?php
        foreach ($_SESSION["tiradas"] as $color) {
            echo "<svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" style=\"margin-left:5px; background-color: $color\">";
            echo "</svg>";
        }

        if ($_SESSION["error"]) {
            echo "<p>¡Lo siento! Se ha equivocado. Pulse Reiniciar para comenzar de nuevo.</p>";
        }

        if ($_SESSION["exito"]) {
            echo "<p>¡Enhorabuena! Ha repetido correctamente la secuencia. Pulse Reiniciar para comenzar de nuevo.</p>";
        }
      ?>

  </div>

</body>

</html>