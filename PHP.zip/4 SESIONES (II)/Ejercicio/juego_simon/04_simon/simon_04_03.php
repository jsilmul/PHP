<?php
session_name("simonparte4");
session_start();

if (!isset($_SESSION["longitud"]) || !isset($_SESSION["objetivo"]) || !isset($_SESSION["jugador"]) || 
    !isset($_SESSION["fallo"]) || !isset($_SESSION["completado"])) {
    
    header("Location:simon_04_01.php");
    exit;
}

function recoge($variable, $color = ""){
    $variableTemporal = is_array($color) ? [] : "";
    if (isset($_REQUEST[$variable])) {
        if (!is_array($_REQUEST[$variable]) && !is_array($color)) {
            $variableTemporal = trim(htmlspecialchars($_REQUEST[$variable]));
        } elseif (is_array($_REQUEST[$variable]) && is_array($color)) {
            $variableTemporal = $_REQUEST[$variable];
            array_walk_recursive($variableTemporal, function (&$valor) {
                $valor = trim(htmlspecialchars($valor));
            });
        }
    }
    return $variableTemporal;
}


$eleccion = recoge("eleccion");
if ($eleccion == "reiniciar") {
    header("Location:simon_04_01.php");
    exit;
}

if ($_SESSION["completado"] || $_SESSION["fallo"]) {
    header("Location:simon_04_02.php");
    exit;
}

if (in_array($eleccion, ["red", "yellow", "blue", "green"])) {
    $_SESSION["jugador"][] = $eleccion;
    $_SESSION["fallo"] = false;
    for ($i = 0; $i < count($_SESSION["jugador"]); $i++) {
        if ($_SESSION["jugador"][$i] != $_SESSION["objetivo"][$i]) {
            $_SESSION["fallo"] = true;
        }
    }
    if (!$_SESSION["fallo"] && count($_SESSION["jugador"]) == count($_SESSION["objetivo"])) {
        $_SESSION["completado"] = true;
    }
}


header("Location:simon_04_02.php");

?>