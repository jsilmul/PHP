<?php
session_name("simonparte4");
session_start();

$colores = ["red", "yellow", "blue", "green"];


if (!isset($_SESSION["longitud"]) || !isset($_SESSION["objetivo"]) || !isset($_SESSION["jugador"]) || 
    !isset($_SESSION["fallo"]) || !isset($_SESSION["completado"]) || $_SESSION["fallo"]) {
    $_SESSION["longitud"] = 3;
    
    unset($_SESSION["objetivo"]);
    for ($i = 0; $i < $_SESSION["longitud"]; $i++) {
        $_SESSION["objetivo"][] = $colores[array_rand($colores)];
    }
    
    $_SESSION["jugador"] = [];
    $_SESSION["fallo"] = false;
    $_SESSION["completado"] = false;
}

if ($_SESSION["completado"]) {
    $_SESSION["longitud"] += 1;
    
    unset($_SESSION["objetivo"]);
    for ($i = 0; $i < $_SESSION["longitud"]; $i++) {
        $_SESSION["objetivo"][] = $colores[array_rand($colores)];
    }
    
    $_SESSION["jugador"] = [];
    $_SESSION["fallo"] = false;
    $_SESSION["completado"] = false;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simón 04 - Aumentar la lista colores gradualmente
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <h1>Simón 04 - Aumentar la lista gradualmente</h1>

    <p>● La primera vez que se juegue, la lista de colores tendrá tres colores.</p>

    <p>● Cada vez que se consiga reproducir la lista de colores, el programa propondrá una lista más larga (un color más cada vez).</p>

    <p>Secuencia a reproducir:</p>


  <div style="display: flex;">

      <?php
          foreach ($_SESSION["objetivo"] as $color) {
            echo "<svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" style=\"margin-left:5px; background-color: $color\">";
            echo "</svg>";
          }
      ?>

  </div>


  <form action="simon_04_02.php" method="post">

    <p>Haga clic para comenzar el juego:</p>

    <p><input type="submit" name="eleccion" value="comenzar"></p>

  </form>


</body>

</html>