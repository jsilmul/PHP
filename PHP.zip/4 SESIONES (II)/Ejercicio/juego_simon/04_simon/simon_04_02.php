<?php
session_name("simonparte4");
session_start();

if (!isset($_SESSION["longitud"]) || !isset($_SESSION["objetivo"]) || !isset($_SESSION["jugador"]) ||
    !isset($_SESSION["fallo"]) || !isset($_SESSION["completado"])) {
    
    header("Location:simon_04_01.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simón 04 - Aumentar la lista colores gradualmente
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

    <form action="simon_04_03.php" method="post">

      <p>Haga clic en los colores:</p>

        <table>
          <tbody>
            <tr>
              <td>
                <button type="submit" name="eleccion" value="red">
                  <div style="background-color: red; width: 100px; height: 100px"></div>
                </button>
              </td>
              <td>
                <button type="submit" name="eleccion" value="yellow">
                  <div style="background-color: yellow; width: 100px; height: 100px"></div>
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <button type="submit" name="eleccion" value="blue">
                  <div style="background-color: blue; width: 100px; height: 100px"></div>
                </button>
              </td>
              <td>
                <button type="submit" name="eleccion" value="green">
                  <div style="background-color: green; width: 100px; height: 100px"></div>
                </button>
              </td>
            </tr>
          </tbody>
        </table>

      <p><input type="submit" name="eleccion" value="reiniciar"></p>

  </form>

  <p>Colores elegidos:</p>

  <div style="display: flex;">

      <?php
          foreach ($_SESSION["jugador"] as $color) {
            echo "<svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" style=\"margin-left:5px; background-color: $color\">";
            echo "</svg>";
          }

          if ($_SESSION["fallo"]) {
            echo "<p>¡Lo siento! Se ha equivocado. Pulse Reiniciar para comenzar de nuevo.</p>";
          }

          if ($_SESSION["completado"]) {
            echo "<p>¡Enhorabuena! Ha repetido correctamente la secuencia. Pulse Reiniciar para intentar el nivel siguiente.</p>";
          }
      ?>

  </div>

</body>

</html>