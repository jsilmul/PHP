<?php
session_name("simonparte1");
session_start();

if (!isset($_SESSION["colores"])) {
    $_SESSION["colores"] = [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Simón 01 - Crear lista de colores
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Simón 01 - Crear lista de colores</h1>

      <p>● Esta primera página contiene un formulario con cinco botones de tipo submit con el mismo name, cuatro para 
          indicar el color elegido y uno para reiniciar el juego.</p>
      <p>● En la segunda página se recibirá el dato, se añadirá un color o se reiniciará y, por último, se redirigirá 
          a la primera página.</p>

  <form action="simon_01_02.php" method="post">
      <p>Haga clic en los colores:</p>

        <table>
          <tbody>
            <tr>
              <td>
                <button type="submit" name="eleccion" value="red">
                  <div style="background-color: red; width: 100px; height: 100px"></div>
                </button>
              </td>
              <td>
                <button type="submit" name="eleccion" value="yellow">
                  <div style="background-color: yellow; width: 100px; height: 100px"></div>
                </button>
              </td>
            </tr>
            <tr>
              <td>
                <button type="submit" name="eleccion" value="blue">
                  <div style="background-color: blue; width: 100px; height: 100px"></div>
                </button>
              </td>
              <td>
                <button type="submit" name="eleccion" value="green">
                  <div style="background-color: green; width: 100px; height: 100px"></div>
                </button>
              </td>
            </tr>
          </tbody>
        </table>

      <p><input type="submit" name="eleccion" value="reiniciar"></p>

  </form>

  <p>Colores elegidos:</p>
  <div style="display: flex;">

      <?php
        foreach ($_SESSION["colores"] as $color) {
          echo "<svg width=\"50\" height=\"50\" viewBox=\"0 0 50 50\" style=\"margin-left: 5px; background-color: $color\">";
          echo "</svg>";
        }
      ?>

  </div>

</body>

</html>