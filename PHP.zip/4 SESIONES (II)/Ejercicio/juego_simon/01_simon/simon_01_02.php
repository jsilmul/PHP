<?php
session_name("simonparte1");
session_start();

if (!isset($_SESSION["colores"])) {
    header("Location: simon_01_01.php");
    exit;
}

function recoge($variable, $color = ""){
    $variableTemporal = is_array($color) ? [] : "";
    if (isset($_REQUEST[$variable])) {
        if (!is_array($_REQUEST[$variable]) && !is_array($color)) {
            $variableTemporal = trim(htmlspecialchars($_REQUEST[$variable]));
        } elseif (is_array($_REQUEST[$variable]) && is_array($color)) {
            $variableTemporal = $_REQUEST[$variable];
            array_walk_recursive($variableTemporal, function (&$valor) {
                $valor = trim(htmlspecialchars($valor));
            });
        }
    }
    return $variableTemporal;
}

$eleccion = recoge("eleccion");
if (in_array($eleccion, ["red", "yellow", "blue", "green"])) {
    $_SESSION["colores"][] = $eleccion;
}

if ($eleccion == "reiniciar") {
    unset($_SESSION["colores"]);
}

header("Location: simon_01_01.php");
?>