<?php

// Se accede a la sesión
    session_name("sesion_tresenraya");
    session_start();

    require_once ("validaciones.php");

    if (!isset($_SESSION["c11"]) || !isset($_SESSION["c12"]) || !isset($_SESSION["c13"]) ||
    !isset($_SESSION["c21"]) || !isset($_SESSION["c22"]) || !isset($_SESSION["c23"]) ||
    !isset($_SESSION["c31"]) || !isset($_SESSION["c32"]) || !isset($_SESSION["c33"])) {
        $_SESSION["c11"]="imagenes/casilla.jfif";
        $_SESSION["c12"]="imagenes/casilla.jfif";
        $_SESSION["c13"]="imagenes/casilla.jfif";
        $_SESSION["c21"]="imagenes/casilla.jfif";
        $_SESSION["c22"]="imagenes/casilla.jfif";
        $_SESSION["c23"]="imagenes/casilla.jfif";
        $_SESSION["c31"]="imagenes/casilla.jfif";
        $_SESSION["c32"]="imagenes/casilla.jfif";
        $_SESSION["c33"]="imagenes/casilla.jfif";
        $_SESSION["turno"]=0;
        

    }
    //Campos jugador 1:
    $correoElectronico1 = $_SESSION["correo1"];
    $edad1  = $_SESSION["edad2"];
    $usuario1=$_SESSION["usuario1"];
    
    //Campos jugador 2:
    $correoElectronico2 = $_SESSION["correo2"];
    $edad2  = $_SESSION["edad2"];
    $usuario2=$_SESSION["usuario2"];



    $casillaMarcada= obtenerValorCampo("casilla");
    //$turno = (int)obtenerValorCampo("turno")+1;
    $_SESSION["turno"]=$_SESSION["turno"]+1;

    switch ($casillaMarcada){
        case "cero":
            $_SESSION["c11"]="imagenes/casilla.jfif";
            $_SESSION["c12"]="imagenes/casilla.jfif";
            $_SESSION["c13"]="imagenes/casilla.jfif";
            $_SESSION["c21"]="imagenes/casilla.jfif";
            $_SESSION["c22"]="imagenes/casilla.jfif";
            $_SESSION["c23"]="imagenes/casilla.jfif";
            $_SESSION["c31"]="imagenes/casilla.jfif";
            $_SESSION["c32"]="imagenes/casilla.jfif";
            $_SESSION["c33"]="imagenes/casilla.jfif";
            $_SESSION["turno"]=0;
            break;
        case "c11":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c11"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c11"]="imagenes/casilla-o.jfif";
            }
            break;
        case "c12":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c12"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c12"]="imagenes/casilla-o.jfif";
            }
            break;
        case "c13":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c13"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c13"]="imagenes/casilla-o.jfif";
                }
            break;
        case "c21":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c21"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c21"]="imagenes/casilla-o.jfif";
            }
            break;
        case "c22":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c22"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c22"]="imagenes/casilla-o.jfif";
            }
            break;
        case "c23":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c23"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c23"]="imagenes/casilla-o.jfif";
            }
            break;
        case "c31":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c31"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c31"]="imagenes/casilla-o.jfif";
            }
            break;
        case "c32":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c32"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c32"]="imagenes/casilla-o.jfif";
            }
            break;

        case "c33":
            if ($_SESSION["turno"]%2==0){
                $_SESSION["c33"]="imagenes/casilla-x.jfif";
            } else{
                $_SESSION["c33"]="imagenes/casilla-o.jfif";
            }
            break;
    }

    if ($_SESSION["turno"]>=9){
        session_start();
    }


    if (($_SESSION["c11"]==$_SESSION["c12"]) and ($_SESSION["c12"]==$_SESSION["c13"])and ($_SESSION["c11"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c21"]==$_SESSION["c22"]) and ($_SESSION["c22"]==$_SESSION["c23"])and ($_SESSION["c21"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c31"]==$_SESSION["c32"]) and ($_SESSION["c32"]==$_SESSION["c33"])and ($_SESSION["c31"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c11"]==$_SESSION["c21"]) and ($_SESSION["c21"]==$_SESSION["c31"])and ($_SESSION["c11"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c12"]==$_SESSION["c22"]) and ($_SESSION["c22"]==$_SESSION["c32"])and ($_SESSION["c12"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c13"]==$_SESSION["c23"]) and ($_SESSION["c23"]==$_SESSION["c33"])and ($_SESSION["c13"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c11"]==$_SESSION["c22"]) and ($_SESSION["c22"]==$_SESSION["c33"])and ($_SESSION["c22"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }elseif (($_SESSION["c31"]==$_SESSION["c22"]) and ($_SESSION["c22"]==$_SESSION["c13"])and ($_SESSION["c22"]!="imagenes/casilla.jfif")){
        $ganada=true;
    }

    header("Location:recu3.php?ganada=$ganada&correo1=$correoElectronico1&correo2=$correoElectronico2&edad1=$edad1&edad2=$edad2&usuario1=$usuario1&usuario2=$usuario2");
?>