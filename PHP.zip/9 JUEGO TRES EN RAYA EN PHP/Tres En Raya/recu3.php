<?php
// Se accede a la sesión
session_name("sesion_tresenraya");
session_start();


    require_once ("validaciones.php");

    
    //Campos jugador 1:
    $correoElectronico1 = obtenerValorCampo("correo1");
    $edad1  = obtenerValorCampo("edad1");
    $usuario1=obtenerValorCampo("usuario1");
    //Campos jugador 2:
    $correoElectronico2 = obtenerValorCampo("correo2");
    $edad2  = obtenerValorCampo("edad2");
    $usuario2=obtenerValorCampo("usuario2");

    if (!isset($_SESSION["c11"]) || !isset($_SESSION["c12"]) || !isset($_SESSION["c13"]) ||
    !isset($_SESSION["c21"]) || !isset($_SESSION["c22"]) || !isset($_SESSION["c23"]) ||
    !isset($_SESSION["c31"]) || !isset($_SESSION["c32"]) || !isset($_SESSION["c33"])) {
        $_SESSION["c11"]="imagenes/casilla.jfif";
        $_SESSION["c12"]="imagenes/casilla.jfif";
        $_SESSION["c13"]="imagenes/casilla.jfif";
        $_SESSION["c21"]="imagenes/casilla.jfif";
        $_SESSION["c22"]="imagenes/casilla.jfif";
        $_SESSION["c23"]="imagenes/casilla.jfif";
        $_SESSION["c31"]="imagenes/casilla.jfif";
        $_SESSION["c32"]="imagenes/casilla.jfif";
        $_SESSION["c33"]="imagenes/casilla.jfif";
        $_SESSION["turno"]=0;
        $_SESSION["ganada"]=false;
        $_SESSION["usuario1"]=$usuario1;
        $_SESSION["usuario2"]=$usuario2;
        $_SESSION["correo1"]=$correoElectronico1;
        $_SESSION["correo2"]=$correoElectronico2;
        $_SESSION["edad1"]=$edad1;
        $_SESSION["edad2"]=$edad2;

    }
    
// Pintamos tanto el correo electrónico como la edad
      echo "<h4> Datos del jugador 1</h4>";
      echo "Jugador 1: <b>$usuario1</b><br>";
      echo "Correo electrónico: <b>$correoElectronico1</b><br>";
      echo "Edad: <b>$edad1 años</b>";
      
      echo "<h4> Datos del jugador 2</h4>";
      echo "Jugador 2: <b>$usuario2</b><br>";
      echo "Correo electrónico: <b>$correoElectronico2</b><br>";
      echo "Edad: <b>$edad2 años</b>";




    $turno=0;
    
    $ganada=obtenerValorCampo("ganada");

    if ($ganada){
        header("Location:recu5.php?ganada=$ganada&correo1=$correoElectronico1&correo2=$correoElectronico2&edad1=$edad1&edad2=$edad2&usuario1=$usuario1&usuario2=$usuario2");
        
    }
    
    

?>




<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h2>3 en Raya</h2>

  <h5 name ="turno" value=<?php echo $turno ?>>Turno: <?php echo ($_SESSION["turno"]+1) ?></h5>

  <form action="recu4.php" method="post">
  <br/>
        <button type="submit" name="casilla" value="c11" ><img src=<?php echo $_SESSION["c11"]?> style="width: 100px; height: 100px"></button>
        <button type="submit" name="casilla" value="c12" ><img src=<?php echo $_SESSION["c12"]?> style="width: 100px; height: 100px"></button>
        <button type="submit" name="casilla" value="c13" ><img src=<?php echo $_SESSION["c13"]?> style="width: 100px; height: 100px"></button>
     <br/>
        <button type="submit" name="casilla" value="c21" ><img src=<?php echo $_SESSION["c21"]?> style="width: 100px; height: 100px"></button>
        <button type="submit" name="casilla" value="c22" ><img src=<?php echo $_SESSION["c22"]?> style="width: 100px; height: 100px"></button>
        <button type="submit" name="casilla" value="c23" ><img src=<?php echo $_SESSION["c23"]?> style="width: 100px; height: 100px"></button>
    <br/>
        <button type="submit" name="casilla" value="c31" ><img src=<?php echo $_SESSION["c31"]?> style="width: 100px; height: 100px"></button>
        <button type="submit" name="casilla" value="c32" ><img src=<?php echo $_SESSION["c32"]?> style="width: 100px; height: 100px"></button>
        <button type="submit" name="casilla" value="c33" ><img src=<?php echo $_SESSION["c33"]?> style="width: 100px; height: 100px"></button>
    <br/>


    <button type="submit" name="casilla" value="cero">Reiniciar</button>
</form>
</body>
</html>