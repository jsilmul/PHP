<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <h1>Introduzca los datos</h1>

    <?php
    require_once ("validaciones.php");
      // Recogemos la edad, el correo electrónico y los avisos correspondientes

      //Campos jugador 1:
      $correoElectronico1 = obtenerValorCampo("correo1");
      $avisoCorreo1 = obtenerValorCampo("avisoCorreo1");
      $edad1  = obtenerValorCampo("edad1");
      $avisoEdad1 = obtenerValorCampo("avisoEdad1");
      $usuario1=obtenerValorCampo("usuario1");
      $avisoUsuario1=obtenerValorCampo("avisoUsuario1");

      //Campos jugador 2:
      $correoElectronico2 = obtenerValorCampo("correo2");
      $avisoCorreo2 = obtenerValorCampo("avisoCorreo2");
      $edad2  = obtenerValorCampo("edad2");
      $avisoEdad2 = obtenerValorCampo("avisoEdad2");
      $usuario2=obtenerValorCampo("usuario2");
      $avisoUsuario2=obtenerValorCampo("avisoUsuario2");
    
    echo "<form action=\"recu2.php\" method=\"post\">";


    

    //-----------------Formulario del usuario 1-------------------

    echo "<p>Nombre jugador 1: <input type=\"text\" placeholder=\"Introduzca su nombre\" name=\"usuario1\" size =\"40\" value=\"$usuario1\"</p>";
    //Mostramos el aviso del usuario 1
    if ($avisoUsuario1){
      print "<p>$avisoUsuario1<p>";
    }

    echo "<p>Correo electrónico: <input type=\"text\" placeholder=\"@email\" name=\"correo1\" size =\"40\" value=\"$correoElectronico1\"</p>";
      
        // Mostramos el aviso del correo electrónico
        if ($avisoCorreo1) {
          print "<p>$avisoCorreo1</p>";
        }
      echo "<p> Indique su edad:  <input type=\"text\" placeholder=\"Entre 18 y 65 años\"name=\"edad1\" size =\"20\" value=\"$edad1\"</p>";
      
        // Mostramos el aviso de la edad
        if ($avisoEdad1) {
          print "<p>$avisoEdad1</p>";
        }





        //-----------Formulario del usuario 2-----------

        echo "<p>Nombre jugador 2: <input type=\"text\" placeholder=\"Introduzca su nombre\" name=\"usuario2\" size =\"40\" value=\"$usuario2\"</p>";
    //Mostramos el aviso del usuario 2
    if ($avisoUsuario2){
      print "<p>$avisoUsuario2<p>";
    }

    echo "<p>Correo electrónico: <input type=\"text\" placeholder=\"@email\" name=\"correo2\" size =\"40\" value=\"$correoElectronico2\"</p>";
      
        // Mostramos el aviso del correo electrónico
        if ($avisoCorreo2) {
          print "<p>$avisoCorreo2</p>";
        }
      echo "<p> Indique su edad:  <input type=\"text\" placeholder=\"Entre 18 y 65 años\"name=\"edad2\" size =\"20\" value=\"$edad2\"</p>";
      
        // Mostramos el aviso de la edad
        if ($avisoEdad2) {
          print "<p>$avisoEdad2</p>";
        }
      ?>
      
      <p>
      <input type="submit">
      <input name=Borrar type=reset value="Borrar">
      </p>

</body>
</html>