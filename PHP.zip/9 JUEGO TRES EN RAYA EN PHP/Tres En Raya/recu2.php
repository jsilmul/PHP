<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Datos</h1>

    <?php
      require_once ("validaciones.php");
      // Recogemos el correo electrónico y la edad

      //Campos jugador 1:
      $correoElectronico1 = obtenerValorCampo("correo1");
      $edad1  = obtenerValorCampo("edad1");
      $usuario1=obtenerValorCampo("usuario1");
      

      //Campos jugador 2:
      $correoElectronico2 = obtenerValorCampo("correo2");
      $edad2  = obtenerValorCampo("edad2");
      $usuario2=obtenerValorCampo("usuario2");
      

      

      $usuarioOk1= false;
      $correoOk1 = false;
      $edadOk1 = false;

      $avisoCorreo1 = "";
      $avisoEdad1   = "";
      $avisoUsuario1="";


      $usuarioOk2= false;
      $correoOk2 = false;
      $edadOk2 = false;
      
      $avisoCorreo2 = "";
      $avisoEdad2   = "";
      $avisoUsuario2= "";


      // Comprobamos los correos. Si detectamos un error, guardamos el aviso correspondiente
      if (!validar_email($correoElectronico1)) {
          $avisoCorreo1 = "No ha escrito su correo electrónico correctamente. Por favor, revíselo.";
      } else {
          $correoOk1 = true;
      }
      if (!validar_email($correoElectronico2)) {
        $avisoCorreo2 = "No ha escrito su correo electrónico correctamente. Por favor, revíselo.";
        } else {
           $correoOk2 = true;
        }
      

      // Comprobamos las edades. Si detectamos un error, guardamos el aviso correspondiente
      if (!validar_entero($edad1)) {
        $avisoEdad1 = "No ha escrito la edad como número. Por favor, revíselo.";
      } elseif ($edad1 < 18 or $edad1 > 65) {
          $avisoEdad1 = "La edad no está entre 18 y 65 años. Por favor, revíselo.";
      } else {
          $edadOk1 = true;
      }
      if (!validar_entero($edad2)) {
        $avisoEdad2 = "No ha escrito la edad como número. Por favor, revíselo.";
      } elseif ($edad2 < 18 or $edad2 > 65) {
          $avisoEdad2 = "La edad no está entre 18 y 65 años. Por favor, revíselo.";
      } else {
          $edadOk2 = true;
      }

      //Comprobamos los usuarios
      if (!validar_requerido($usuario1)) {
        $avisoUsuario1 = "Este campo debe contener algo.";
    } else {
        $usuarioOk1 = true;
    }
    if (!validar_requerido($usuario2)) {
      $avisoUsuario2 = "Este campo debe contener algo.";
      } else {
         $usuarioOk2 = true;
      }



      // Si hay algún error, volvemos al formulario enviando los avisos y los datos recibidos
      if (!$usuarioOk1 or !$correoOk1 or !$edadOk1 or !$usuarioOk2 or !$correoOk2 or !$edadOk2) {
          header("Location:recu1.php?correo1=$correoElectronico1&correo2=$correoElectronico2&avisoCorreo1=$avisoCorreo1&avisoCorreo2=$avisoCorreo2&edad1=$edad1&edad2=$edad2&avisoEdad1=$avisoEdad1&avisoEdad2=$avisoEdad2&usuario1=$usuario1&usuario2=$usuario2&avisoUsuario1=$avisoUsuario1&avisoUsuario2=$avisoUsuario2");
          
          // Paramos la ejecución de código
          exit();
      }

      
      // Pintamos tanto el correo electrónico como la edad
      echo "<h3> Datos del jugador 1</h3>";
      echo "<p>Jugador 1: <b>$usuario1</b>";
      echo "<p>Correo electrónico: <b>$correoElectronico1</b>";
      echo "<br>Edad: <b>$edad1 años</b></br>";
      
      echo "<h3> Datos del jugador 2</h3>";
      echo "<p>Jugador 2: <b>$usuario2</b>";
      echo "<p>Correo electrónico: <b>$correoElectronico2</b>";
      echo "<br>Edad: <b>$edad2 años</b></br>";

      header("Location:recu3.php?correo1=$correoElectronico1&correo2=$correoElectronico2&edad1=$edad1&edad2=$edad2&usuario1=$usuario1&usuario2=$usuario2");

    ?>
<p><a href="recu1.php">Volver al inicio.</a></p>
<!-- <p><a href="recu1.php">Volver al inicio.</a></p>-->

</body>
</html>
