<?php
session_name("sesion_tresenraya");
session_start();

echo "<h2>La partida está ganada por:</h2>";
        if ($_SESSION["turno"]%2==0){
            echo "<h1>";
            echo $_SESSION["usuario2"];
            echo "</h1>";
            session_destroy();
        }else{
            echo "<h1>";
            echo $_SESSION["usuario1"];
            echo "</h1>";
            session_destroy();
        }
        
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
<form action="recu1.php" method="post">
<button type="submit">Volver a jugar</button>
</form>
</body>
</html>