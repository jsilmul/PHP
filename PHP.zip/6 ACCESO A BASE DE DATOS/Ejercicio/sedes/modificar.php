<?php
    require_once("../utiles/variables.php");
    require_once("../utiles/funciones.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar una sede</title>
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
</head>
<body>
    <h1>Modificar una sede</h1>
    <?php

    	$errores = [];
    	$comprobarValidacion = false;
    	$idSede = 0;
    	
    	if (count($_REQUEST) > 0)
    	{

		    if (isset($_GET["idSede"]))
		    {
            	$idSede = $_GET["idSede"];
          
            	//Obtenemos los datos de la sede
            	$conexion = conectarPDO($host, $user, $password, $bbdd);

        		// consulta a ejecutar
        		$select = "SELECT nombre, direccion FROM sedes s WHERE s.id = ? ";

		        // preparar la consulta
		        $consulta = $conexion->prepare($select);

		        // parámetro
		        $consulta->bindParam(1, $idSede);

		        // ejecutar la consulta 
		        $consulta->execute();

		        // comprobamos si hay algún registro 
				if ($consulta->rowCount() == 0)
				{
					$consulta = null;
					$conexion = null;
					header("Location: listado.php");
					exit();
				}
				else 
				{
					// Obtenemos el resultado
			        $registro = $consulta->fetch();
			        
			        $sede = $registro['nombre'];
			        $direccion = $registro['direccion'];
			        
			        $consulta = null;

			        $conexion = null;
				}

        	} 
        	else 
        	{

        		$comprobarValidacion = true;
        		$longitudMinimaSede = 3;
			    $longitudMaximaSede = 50;
			    $longitudMinimaDireccion = 10;
			    $longitudMaximaDireccion = 255;

        		// Obtenemos el campo del nombre de la sede y dirección
			    $idSede = obtenerValorCampo("id");
			    $sede = obtenerValorCampo("nombre");
			    $direccion = obtenerValorCampo("direccion");
			    
			    //-----------------------------------------------------
		        // Validaciones
		        //-----------------------------------------------------
				// Compruebo que el id de la sede se corresponde con una que tengamos 
	        	$conexion = conectarPDO($host, $user, $password, $bbdd);

	        	// consulta a ejecutar
				$select = "SELECT * FROM sedes where id = :id";

				// preparar la consulta
				$consulta = $conexion->prepare($select);

				$consulta->bindParam(':id', $idSede); 

				// ejecutar la consulta 
				$consulta->execute();

				// comprobamos si algún registro 
				if ($consulta->rowCount() == 0)
				{
					$consulta = null;
					$conexion = null;
					header("Location: listado.php");
					exit();
				}

				$consulta = null;

        		$conexion = null;

		        // Nombre de la sede
		        if (!validarLongitudCadena($sede, $longitudMinimaSede ,$longitudMaximaSede)) 
		        {
		            $errores["sede"] = "La sede de la empresa tiene que tener una longitud mínima de $longitudMinimaSede y máxima de $longitudMaximaSede caracteres.";
		        }
		        // Dirección de la sede
		        if (!validarLongitudCadena($direccion, $longitudMinimaDireccion, $longitudMaximaDireccion)) 
		        {
		            $errores["direccion"] = "La direccion de la empresa tiene que tener una longitud mínima de $longitudMinimaDireccion y máxima de $longitudMaximaDireccion caracteres.";
		        }

        	}
		    
    	} 
    	else 
    	{
    		// redireccionamos al listado de sedes si se accede directamente
  			header("Location: listado.php");
  			exit();
    	}
  	?>

  	<?php
  		if (!$comprobarValidacion || count($errores) > 0):
  
  	?>
  		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
  			<input type="hidden" name="id" value="<?php echo $idSede ?>">
	    	<p>
	            <!-- Campo nombre de la sede -->
	            <input type="text" name="nombre" placeholder="Sede" value="<?php echo $sede ?>">
	            <?php
	            	if (isset($errores["sede"])):
	            ?>
	            	<p class="error"><?php echo $errores["sede"] ?></p>
	            <?php
	            	endif;
	            ?>
	        </p>
	        <p>
	            <!-- Campo dirección de la sede -->
	            <input type="text" name="direccion" placeholder="Dirección" value="<?php echo $direccion ?>">
	            <?php
	            	if (isset($errores["direccion"])):
	            ?>
	            	<p class="error"><?php echo $errores["direccion"] ?></p>
	            <?php
	            	endif;
	            ?>
	        </p>
	        <p>
	            <!-- Botón submit -->
	            <input type="submit" value="Guadar">
	        </p>
	    </form>
  	<?php
  		else:
  			$conexion = conectarPDO($host, $user, $password, $bbdd);

			// consulta a ejecutar
			$update = "update sedes set nombre = :nombre, direccion = :direccion where id = :id";

			// preparar la consulta
			$consulta = $conexion->prepare($update);
			
			$consulta->bindParam(':nombre', $sede); 
			$consulta->bindParam(':direccion', $direccion); 
			$consulta->bindParam(':id', $idSede);

			// ejecutar la consulta 
			$consulta->execute();
			
			$consulta = null;

        	$conexion = null;

        	// redireccionamos al listado de sedes
  			header("Location: listado.php");
  			
    	endif;
    ?>
    <div class="contenedor">
        <div class="enlaces">
            <a href="listado.php">Volver al listado de sedes</a>
        </div>
   	</div>
    
</body>
</html>