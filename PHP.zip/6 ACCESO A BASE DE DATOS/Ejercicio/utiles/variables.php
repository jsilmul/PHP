<?php

	// Definición de variables
	$host = "localhost";
	$user = "dwes_tarde";
	$password = "dwes_2223";
	$bbdd = "dwes_tarde_empresa";
?>