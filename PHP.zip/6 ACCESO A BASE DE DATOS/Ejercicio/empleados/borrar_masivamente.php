<?php
    require_once("../utiles/variables.php");
    require_once("../utiles/funciones.php");

    if (count($_REQUEST) > 0)
    {

	    if (isset($_REQUEST["empleados"])) 
	    {
	    	$empleados = $_REQUEST["empleados"];

	    	$conexion = conectarPDO($host, $user, $password, $bbdd);

			// consulta a ejecutar
			$delete = "DELETE FROM empleados where id = ?";

			// preparar la consulta
			$consulta = $conexion->prepare($delete);

			try 
			{
  				$conexion->beginTransaction();

  				foreach ($empleados as $empleado) 
  				{
  					$consulta->bindParam(1, $empleado);
  					$consulta->execute();
  				}

  				$consulta = null;

  				$conexion->commit();

  				echo "<h2>Empleados eliminados con éxito.</h2>";
  			} 
  			catch (Exception $e) 
  			{
  				echo "<h2>No se ha podido eliminar los empleados.</h2>";
  				$conexion->rollback();
  				exit();
			}

			$conexion = null;
        	
	    	header("refresh:3;url=listado.php");
	    	exit();

	    } 
	    else 
	    {
			// redireccionamos al listado de sedes si se accede directamente
	  		header("Location: listado.php");
	  		exit();
		}
	} 
	else 
	{
		// redireccionamos al listado de sedes si se accede directamente
  		header("Location: listado.php");
  		exit();
	}
?>