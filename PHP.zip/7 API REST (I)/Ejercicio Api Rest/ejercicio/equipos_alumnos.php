<?php
	require_once("../funciones.php");

	$conexion = conectar_pdo($host, $user, $password, $bbdd);
  	$datos = '';
  
  	/*
   	 dar de alta un jugador en un equipo
  	*/
  	if ($_SERVER['REQUEST_METHOD'] == 'POST')
  	{
    	// Transformamos el JSON de entrada de datos a un array asociativo 
    	$equipoAlumno = json_decode(file_get_contents('php://input'), true);
    	$equipo = $equipoAlumno["equipo_id"];
    	$alumno = $equipoAlumno["alumno_id"];

    	// Obtenemos si es un alumno válido
    	$select = "SELECT * FROM alumnos where id = ?";
    	$consulta = $conexion->prepare($select);
    	$consulta->bindParam(1, $alumno);
    	$consulta->execute();
    	$datosAlumno = $consulta->fetch(PDO::FETCH_ASSOC);
    	

    	if ($consulta->rowCount() < 1) {
         	$datos = json_encode(array('mensaje' => "Alumno incorrecto"));
          	header ($headerJSON);
          	header ($codigosHTTP["400"]);
		} else {

    		$consulta = null;

    		// Obtenemos si el alumno está en algún equipo
    		$select = "SELECT * FROM equipos_alumnos where alumno_id = ?";
		    $consulta = $conexion->prepare($select);
		    $consulta->bindParam(1, $alumno);
		    $consulta->execute();
		   
	    	if ($consulta->rowCount() > 0) {
	         	$datos = json_encode(array('mensaje' => "Alumno ya está en un equipo"));
	          	header ($headerJSON);
	          	header ($codigosHTTP["400"]);
			} else {
		    	$consulta = null;
		    	
	    		// Obtenemos si es un equipo válido
		    	$select = "SELECT * FROM equipos where id = ?";
		    	$consulta = $conexion->prepare($select);
		    	$consulta->bindParam(1, $equipo);
		    	$consulta->execute();
		    	$datosEquipo = $consulta->fetch(PDO::FETCH_ASSOC);

				if ($consulta->rowCount() < 1) {
			    	$datos = json_encode(array('mensaje' => "Equipo incorrecto"));
		          	header ($headerJSON);
		          	header ($codigosHTTP["400"]);
		        } else {
		    	
		        	$consulta = null;

		        	// Obtenemos el número de jugadores en el equipo
			    	$select = "SELECT count(*) jugadores FROM equipos_alumnos where equipo_id = ?";
			    	$consulta = $conexion->prepare($select);
			    	$consulta->bindParam(1, $equipo);
			    	$consulta->execute();
			    	$numeroJugadoresEquipo = $consulta->fetchColumn();
			    	
			    	$consulta = null;

			    	$deporte = $datosEquipo["deporte_id"];
			    	$nombreEquipo = $datosEquipo["nombre"];
			    	$edadMinima = $datosEquipo["edad_minima"];
			    	$edadAlumno = $datosAlumno["edad"];

			    	// Obtenemos datos del número de jugadores del deporte
			    	$select = "SELECT numero_jugadores FROM deportes where id = ?";
			    	$consulta = $conexion->prepare($select);
			    	$consulta->bindParam(1, $deporte);
			    	$consulta->execute();
			    	$numeroJugadores = $consulta->fetchColumn();
			    	$consulta = null;

			    	
			    	if ($numeroJugadoresEquipo >= $numeroJugadores) {
			    		
			    		$datos = json_encode(array('mensaje' => "Equipo con nombre $nombreEquipo está completo y no admite más alumnos."));
		          		header ($headerJSON);
		          		header ($codigosHTTP["400"]);
			    	} elseif (($edadAlumno < $edadMinima) || ($edadAlumno > ($edadMinima +2))) {
			    		$datos = json_encode(array('mensaje' => "El alumno no cumple los requisitos de edad para estar en el equipo."));
		          		header ($headerJSON);
		          		header ($codigosHTTP["400"]);
			    	} else{
			    		//Añado el alumno al equipo
			    		$insert = "INSERT INTO equipos_alumnos (equipo_id, alumno_id) VALUES (:idEquipo, :idAlumno)";
        
			        	$consulta = $conexion->prepare($insert);

			        	$consulta->bindParam(":idEquipo", $equipo);
			        	$consulta->bindParam(":idAlumno", $alumno);
			        
		        		try {
				          $consulta->execute();
				          $datos = json_encode($equipoAlumno);
				          header($headerJSON);
				          header($codigosHTTP["200"]);
		        		} catch (PDOException $exception) {

				          $errorDescription = $exception->getMessage();
				          $datos = json_encode(array('error' => $errorDescription));
				          header ($headerJSON);
				          header ($codigosHTTP["500"]);
				        }
	
			    	}
		        }
			}

    	}

    	print $datos;
    	exit();
  	}
  
//En caso de que ninguna de las opciones anteriores se haya ejecutado
header ($headerJSON);
header ($codigosHTTP["400"]);
print $datos;
?>