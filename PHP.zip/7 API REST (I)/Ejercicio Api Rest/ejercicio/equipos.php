<?php
	require_once("../funciones.php");

	$conexion = conectar_pdo($host, $user, $password, $bbdd);
  	$datos = '';

  	/*
      listar todos los equipos o uno sólo con todos los alumnos que hay en el mismo
  	*/
  	if ($_SERVER['REQUEST_METHOD'] == 'GET')
  	{
    	if (isset($_GET['id'])) {
      		$idEquipo = $_GET['id'];
//Mostrar un equipo y los alumnos que hay en él
	      	$select = "SELECT e.id, e.nombre equipo, edad_minima, d.nombre deporte, d.numero_jugadores numero, a.nombre, a.apellidos, edad 
          FROM equipos e INNER JOIN deportes d ON d.id = e.deporte_id
          LEFT JOIN equipos_alumnos ea ON e.id=ea.equipo_id 
          LEFT JOIN alumnos a ON a.id=ea.alumno_id 
          
          where e.id=:id";
          
	      	$consulta = $conexion->prepare($select);
	      	$consulta->bindParam(':id', $idEquipo);
	      	$consulta->execute();
	      
	      	if ($consulta->rowCount() > 0) {
	        	$equipo = [];
	        	$alumnos= [];
	        	while ($alumnosEquipo = $consulta->fetch(PDO::FETCH_ASSOC)) {
	          		if ($alumnosEquipo["apellidos"] != null) {
	            		$alumnos[] = [
	                		"nombre" => $alumnosEquipo["nombre"] , 
                      "apellidos" => $alumnosEquipo["apellidos"] , 
                      "edad" => $alumnosEquipo["edad"] 
	              		];
	          		}
	          		$equipo = [
	            		"id" => $alumnosEquipo["id"],
	            		"nombre" => $alumnosEquipo["equipo"],
	            		"edad_minima" => $alumnosEquipo["edad_minima"],
                  "deporte" => $alumnosEquipo["deporte"],
                  "numero jugadores" => $alumnosEquipo["numero"],
	            		"alumnos" => $alumnos
	          		];
	        	}

	        	$datos = json_encode($equipo);
	        	header($headerJSON);
	        	($codigosHTTP["200"]);
	      	} else {
	        	header($codigosHTTP["404"]);
            echo "No existe ese equipo";
  
	      	}

	  	} else {
          //Mostrar lista de equipos
	      	$select = "SELECT e.id, e.nombre, edad_minima, d.nombre deporte, d.numero_jugadores numero 
          FROM equipos e INNER JOIN deportes d ON d.id = e.deporte_id";
	      	$consulta = $conexion->prepare($select);
	      	$consulta->execute();
	      	$equipos = [];
	     	  while ($equipo = $consulta->fetch(PDO::FETCH_ASSOC)) {
	        	$equipos[] = $equipo; 
	      	}
	      	$consulta = null;
	      	$datos = json_encode($equipos);
	     	// Listado de equipos	
	     	header($headerJSON);
	      	header($codigosHTTP["200"]);
	  	}

    	$conexion = null;

    	print $datos;
    	exit();
  	}

/*
  actualizar un equipo
*/
  if ($_SERVER['REQUEST_METHOD'] == 'PUT')
  {
      // Transformamos el JSON de entrada de datos a un array asociativo 
      $equipo = json_decode(file_get_contents('php://input'), true);
      $equipoId = $equipo['id'];
      $deporteId=$equipo['deporte_id'];
      $limiteInferiorEdad = 7;
      $limiteSuperiorEdad = 14;
                   
      // Comprobamos si el equipo tiene alumnos
      $select = "SELECT count(*) as numeroJugadores from equipos_alumnos where equipo_id = ?";
      $consulta = $conexion->prepare($select);
      $consulta->bindParam(1, $equipoId);
      $consulta->execute();
      $numeroJugadoresEquipo = $consulta->fetchColumn();
      $consulta = null;

      // No podemos modificar el equipo si ya tiene alumnos
      if ($numeroJugadoresEquipo > 0){
        $datos = json_encode(array('mensaje' => "Equipo no se puede actualizar por tener ya alumnos"));
        header ($headerJSON);
        header ($codigosHTTP["200"]);
      } else {

          //comprobamos si existe el deporte
          $select = "SELECT count(*) from deportes where id = ?";
          $consulta = $conexion->prepare($select);
          $consulta->bindParam(1, $deporteId);
          $consulta->execute();
          $tipoDeporte = $consulta->fetchColumn();
          $consulta = null;
          
          If ($tipoDeporte < 1){
            $datos = json_encode(array('mensaje' => "El deporte no existe"));
          header ($headerJSON);
          header ($codigosHTTP["200"]);
          print $datos;
          exit();
          }

        if (validar_entero_limites($equipo["edad_minima"], $limiteInferiorEdad, $limiteSuperiorEdad)) {
          $campoNombre = "nombre = :nombre";
          $campoEdad= "edad_minima = :edad";
          $campoDeporte = "deporte_id = :deporte";
          $update = "
                UPDATE equipos
                SET $campoNombre, $campoEdad, $campoDeporte
                WHERE id=:equipo
                 ";

          $consulta = $conexion->prepare($update);
          $consulta->bindParam(":nombre", $equipo["nombre"]);
          $consulta->bindParam(":edad", $equipo["edad_minima"]);
          $consulta->bindParam(":deporte", $equipo["deporte_id"]);
          $consulta->bindParam(":equipo", $equipoId);
         
          $consulta->execute();
          $errores = $consulta->errorInfo();
          if (count ($errores)) {
            $datos = json_encode(array('mensaje' => "Equipo actualizado correctamente."));
            header ($headerJSON);
            header ($codigosHTTP["200"]);
          } else {
            $datos = json_encode(array('error' => $errores));
            header ($headerJSON);
            header ($codigosHTTP["500"]);
          }
        } else { 
          $datos = json_encode(array('mensaje' => "La edad mínima debe estar entre $limiteInferiorEdad y $limiteSuperiorEdad años."));
          header ($headerJSON);
          header ($codigosHTTP["400"]);
        }
        
      }

      $consulta = null;
      $conexion = null;

      print $datos;
      exit();
  }

//En caso de que ninguna de las opciones anteriores se haya ejecutado
header ($headerJSON);
header ($codigosHTTP["400"]);
print $datos;
?>