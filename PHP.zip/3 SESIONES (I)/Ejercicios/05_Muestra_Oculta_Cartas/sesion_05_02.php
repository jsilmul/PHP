<?php

//Crear sesión
session_name("muestra_oculta_cartas");
//Iniciar sesión
session_start();

if(isset($_POST['action'])) {
   if($_POST['action'] == 'add') {
      $_SESSION['num_cards']++;
      if($_SESSION['num_cards'] > 52) {
         $_SESSION['num_cards'] = 52;
      }
   } elseif($_POST['action'] == 'remove') {
      $_SESSION['num_cards']--;
      if($_SESSION['num_cards'] < 1) {
         $_SESSION['num_cards'] = 1;
      }
   } elseif($_POST['action'] == 'reset') {
      session_destroy();
      header("Location: sesion_05_01.php");
   }
}
header("Location: sesion_05_01.php");
?>

