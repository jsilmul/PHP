<?php
//Crear sesión
session_name("muestra_oculta_cartas");
//Iniciar sesión
session_start();


if(!isset($_SESSION['cards'])) {
  $_SESSION['cards'] = array();
  for($i = 1; $i <= 52; $i++) {
    array_push($_SESSION['cards'], $i);
  }
  shuffle($_SESSION['cards']);
}
if(isset($_POST['action'])) {
  if($_POST['action'] == 'add') {
    $_SESSION['num_cards']++;
  } elseif($_POST['action'] == 'remove') {
    $_SESSION['num_cards']--;
  } elseif($_POST['action'] == 'reset') {
    session_destroy();
    header("Location: index.php");
  }
}
if(!isset($_SESSION['num_cards'])) {
  $_SESSION['num_cards'] = 4;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sesión 05 - Muestra y oculta cartas
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
 
  <form action="sesion_05_02.php" method="post">

  <p><strong>Número de cartas:</strong>
		<input type="submit" name="action" value="remove" <?php if($_SESSION['num_cards'] <= 1) echo 'disabled'; ?>>
		<?php echo $_SESSION['num_cards']; ?>
		<input type="submit" name="action" value="add" <?php if($_SESSION['num_cards'] >= 52) echo 'disabled'; ?>>
		</p>
		<p><input type="submit" name="action" value="reset"></p>
    
    <p>
        <img src="cartas/dorso-rojo.svg" alt="dorso" width="100"> 
<?php
  // Mostramos las cartas que se han ido pidiendo
  
   $num_cards = $_SESSION['num_cards'];
		echo '<div style="font-size: 0;">';
		for($i = 0; $i < $num_cards; $i++) {
			echo '<img src="cartas/' . $_SESSION['cards'][$i] . '.svg" alt="Carta ' . $_SESSION['cards'][$i] . '" style="width: 100px;">';
		}
		echo '</div>';
  
?>

    </p>

    <p><input type="submit" name="accion" value="reiniciar"></p>
  </form>

  
</body>
</html>
