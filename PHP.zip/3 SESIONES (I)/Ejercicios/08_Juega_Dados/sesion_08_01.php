<?php

 print "<p>Ejercicio incompleto</p>";

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Juego dados
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Juego dados</h1>

    
    <?php

         print "<p>Ejercicio incompleto</p>";

    ?>
    <h3>Dados del Jugador 1</h3>
    <p>
      <?php

        // Pintamos los dados del jugador 1
        print "<p>Ejercicio incompleto</p>";

      ?>
    </p>
    <h3>Dados del Jugador 2</h3>
    <p>
      <?php

        // Pintamos los dados del jugador 2
         print "<p>Ejercicio incompleto</p>";
      
      ?>
    </p>
    <h3>Dados únicos del Jugador 1</h3>
    <p>
      <?php

        // Pintamos los dados únicos del jugador 1
        print "<p>Ejercicio incompleto</p>";

      ?>

    <h3>Dados únicos del Jugador 2</h3>
    <p>
      <?php
        
        // Pintamos los dados únicos del jugador 2
        print "<p>Ejercicio incompleto</p>";
      
      ?>
    </p>
    <h3>Puntuaciones:</h3>
    
    <?php

     print "<p>Ejercicio incompleto</p>";
    
    ?>

    <h3>Resumen:</h3>

    <?php

     print "<p>Ejercicio incompleto</p>";
    
    ?>

</body>
</html>