<?php

   print "<p>Ejercicio incompleto</p>";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sesión 06 - Siete y media
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
 
  <form action="sesion_06_02.php" method="post">
    <p>Haga clic en el dorso de la carta para pedir otra carta:</p>

    <p>
      <button type="submit" name="accion" value="otra">
        <img src="cartas/dorso-rojo.svg" alt="dorso" width="100">

      </button>
<?php
  
  // Mostramos las cartas que se han ido pidiendo
  
   print "<p>Ejercicio incompleto</p>";
  
?>

    </p>

    <p><input type="submit" name="accion" value="reiniciar"></p>
  </form>

  
</body>
</html>
