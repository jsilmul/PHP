<?php
//Crear sesión
session_name("app");
//Iniciar sesión
session_start();


?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sesión 06 - Siete y media
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

<?php
// Inicializamos las variables de sesión si es la primera vez que se accede a la página
if (!isset($_SESSION["cartas"])) {
  $_SESSION["cartas"] = array();
}
if (!isset($_SESSION["puntuacion"])) {
  $_SESSION["puntuacion"] = 0;
}

// Función que devuelve una carta aleatoria que no haya salido antes
function obtenerCarta() {
  $cartas = array("1", "2", "3", "4", "5", "6", "7", "J", "Q", "K");
  $palos = array("corazones", "diamantes", "treboles", "picas");

  do {
    $carta = $cartas[array_rand($cartas)];
    $palo = $palos[array_rand($palos)];
  } while (in_array("$carta-$palo", $_SESSION["cartas"]));

  $_SESSION["cartas"][] = "$carta-$palo";
  return "$carta de $palo";
}

// Comprobamos si se ha pulsado el botón de "otra carta"
if (isset($_POST["accion"]) && $_POST["accion"] == "otra") {
  $carta = obtenerCarta();

  // Sumamos la puntuación de la carta
  if (is_numeric($carta[0])) {
    $_SESSION["puntuacion"] += $carta[0];
  } else {
    $_SESSION["puntuacion"] += 0.5;
  }

  // Comprobamos si se ha ganado o perdido
  if ($_SESSION["puntuacion"] == 7.5) {
    $mensaje = "😎 ¡Has ganado!";
  } elseif ($_SESSION["puntuacion"] > 7.5) {
    $mensaje = "😢 ¡Has perdido!";
  } else {
    $mensaje = "";
  }
}

// Comprobamos si se ha pulsado el botón de "reiniciar"
if (isset($_POST["accion"]) && $_POST["accion"] == "reiniciar") {
  $_SESSION["cartas"] = array();
  $_SESSION["puntuacion"] = 0;
  $mensaje = "";
}
?>

</body>
</html>
