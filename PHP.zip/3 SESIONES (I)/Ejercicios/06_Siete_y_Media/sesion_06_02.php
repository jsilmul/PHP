<?php
//Crear sesión
session_name("app");
//Iniciar sesión
session_start();


if(isset($_POST['accion'])) { // Si se ha enviado el formulario

    // Si se ha pulsado el botón "otra", se añade una carta y se actualiza la puntuación
    if($_POST['accion'] == 'otra') {
        
        // Si no existe la variable de sesión "cartas", se inicializa
        if(!isset($_SESSION['cartas'])) {
            $_SESSION['cartas'] = array();
            $_SESSION['puntuacion'] = 0;
        }
        
        // Se elige una carta al azar del array de cartas permitidas
        $cartas_permitidas = array('1', '2', '3', '4', '5', '6', '7', 'J', 'Q', 'K');
        $carta_elegida = $cartas_permitidas[array_rand($cartas_permitidas)];
        
        // Se añade la carta al array de cartas de la partida
        $_SESSION['cartas'][] = $carta_elegida;
        
        // Se actualiza la puntuación de la partida
        if(is_numeric($carta_elegida)) { // Si es una carta numérica
            $_SESSION['puntuacion'] += $carta_elegida;
        } else { // Si es una carta con letra
            $_SESSION['puntuacion'] += 0.5;
        }
    }
    
    // Si se ha pulsado el botón "reiniciar", se borran los datos de la partida
    if($_POST['accion'] == 'reiniciar') {
        unset($_SESSION['cartas']);
        unset($_SESSION['puntuacion']);
    }
}

// Mostramos las cartas que se han ido pidiendo
if(isset($_SESSION['cartas'])) {
    foreach($_SESSION['cartas'] as $carta) {
        echo '<img src="cartas/' . $carta . '.svg" alt="' . $carta . '" width="100">';
    }
}

// Mostramos la puntuación actual de la partida
if(isset($_SESSION['puntuacion'])) {
    echo '<p>Puntuación: ' . $_SESSION['puntuacion'] . '</p>';
}

// Comprobamos si se ha ganado o perdido la partida y mostramos el mensaje correspondiente
if(isset($_SESSION['puntuacion']) && $_SESSION['puntuacion'] >= 7.5) {
    echo '<p>¡Has ganado! 😎</p>';
    // Borramos los datos de la partida para empezar de nuevo
    unset($_SESSION['cartas']);
    unset($_SESSION['puntuacion']);
} elseif(isset($_SESSION['puntuacion']) && $_SESSION['puntuacion'] > 7.5) {
    echo '<p>¡Has perdido! 😢</p>';
    // Borramos los datos de la partida para empezar de nuevo
    unset($_SESSION['cartas']);
    unset($_SESSION['puntuacion']);
}

?>