<?php
//Accedemos a la sesión
session_name("solicitarnombre");
//Iniciamos la sesión
session_start();

//Si la variable de sesión no está definida
if (!isset($_SESSION["nombre"])) {
  //Creamos la variable de la sesión
  $_SESSION["nombre"] = [];
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Sesión 01 - Datos en sesión
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Almacenamiento de datos en sesión</h1>

    <p>Escriba un formulario que solicite nombres y los almacene en una sesión hasta que el usuario cierre la sesión.</p>
    <p>La primera página:</p>
    <p>● solicita un nombre</p>
    <p>● muestra todos los valores escritos anteriormente en forma de lista.</p>
    <p>● muestra un enlace para borrar todos los valores escritos anteriormente.</p>

  <form action="sesion_01_02.php" method="post">

    <p><label>Escriba algún nombre: <input type="text" name="nombre" size="30" maxlength="30"></label></p>
    <p>
      <input type="submit" value="Añadir">
      <input type="reset" value="Borrar">
    </p>

    <?php
    //Si no hay ningun dato guardado
    if (!count($_SESSION["nombre"])) {
      //Lo indicamos
      echo "<p>Todavía no se han introducido datos: </p>";
    } else {
      //Si lo hay, lo mostramos
      echo "<p>Nombres introducidos:</p>";
      //Para que aparezcan en forma de lista no ordenada
      echo "<ul>";


    foreach ($_SESSION["nombre"] as $valor) {
      //Mostramos el valor
      echo "<li>$valor</li>";
    }
      echo "</ul>";
      //Botón de cierre de sesión
      echo "<p> <input type=\"submit\" name=\"accion\" value=\"Cierra Sesión\"> (Se perderán los datos almacenados) </p>";
    }
    ?>

  </form>

</body>

</html>