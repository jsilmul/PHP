<?php
//Accedemos a la sesión
session_name("solicitarnombre");
//Iniciamos la sesión
session_start();


//Si la variable de sesión no está definida
if (!isset($_SESSION["nombre"])) {
  //Volvemos a la primera página
  header("Location: sesion_01_01.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Sesión 01-02 - Datos en sesión
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

  <h1>Almacenamiento de datos en sesión</h1>

    <p>La segunda página comprueba:</p>
    <p>● si se ha escrito algo de texto, lo guarda en $_SESSION.</p>
    <p>● si se ha pedido borrar todos los nombres, los borra.</p>
    <p>● en todos los casos, vuelve automáticamente a la primera página.</p>

  <?php
  /**
   * Método que devuelve valor de una clave del REQUEST limpia o cadena vacía si no existe
   * @param {string} - Clave del REQUEST de la que queremos obtener el valor
   * @return {string}
   */
  function obtenerValorCampo(string $campo): string{
    if (isset($_REQUEST[$campo])) {
      $valor = trim(htmlspecialchars($_REQUEST[$campo], ENT_QUOTES, "UTF-8"));
    } else {
      $valor = "";
    }

    return $valor;
  }

  $recogerNombre = obtenerValorCampo("nombre");
  $cerrarSesion = obtenerValorCampo("accion");

  if (!$recogerNombre == "") {
    $_SESSION["nombre"][] = $recogerNombre;
  }

  if ($cerrarSesion == "Cierra Sesión") {
    //Cerramos la sesión 
    session_destroy();
    //Y volvemos a la primera página
    header("Location: sesion_01_01.php");
    exit;
  }


  header("Location: sesion_01_01.php");
  ?>

</body>

</html>