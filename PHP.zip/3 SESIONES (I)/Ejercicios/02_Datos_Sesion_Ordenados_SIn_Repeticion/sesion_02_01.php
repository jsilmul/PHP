<?php
//Creamos la sesión
session_name("sinrepeticion");
//Accedemos a la sesión
session_start();

//Si la variable de sesión llamada "datos" no está definida
if (!isset($_SESSION["datos"])) {
  //Creamos dicha variable de la sesión
  $_SESSION["datos"] = [];
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Sesión 02 - Datos en sesión ordenados y sin repetición
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

  <h1>Almacenamiento de datos en sesión</h1>

    <p>La primera página:</p>
    <p>● solicita un nombre.</p>
    <p>● muestra todos los valores escritos anteriormente en forma de lista ordenados alfabéticamente.</p>
    <p>● muestra un enlace para borrar todos los valores escritos anteriormente.</p>

  <form action="sesion_02_02.php" method="post">

    <p><label>Escriba algún nombre: <input type="text" name="datos" size="30" maxlength="30"></label></p>

    <p>
      <input type="submit" value="Añadir">
      <input type="reset" value="Borrar">
    </p>

    <?php
    //Si no hay ningun dato guardado
    if (!count($_SESSION["datos"])) {
      //Lo indicamos
      echo "<p>Todavía no se ha introducido ningún nombre: </p>";
    } else {
      //Si lo hay, lo mostramos
      echo "<p>Nombres ya introducidos:</p>";
      //Para que salga en forma de lista no ordenada
      echo "<ul>";
    foreach ($_SESSION["datos"] as $valor) {
      //Mostramos los valores
      echo "<li>$valor</li>";
    }
      echo "</ul>";
      //Botón de cierre de sesión
      echo "<p> <input type=\"submit\" name=\"cerrar\" value=\"Cerrar Sesión\"> (Se perderán los datos almacenados) </p>";
    }
    ?>

  </form>

</body>

</html>