<?php
//Creamos la sesión
session_name("sinrepeticion");
//Accedemos a la sesión
session_start();

//Si la variable de sesión llamada "datos"  no está definida
if (!isset($_SESSION["datos"])) {
  //Volvemos a la primera página
  header("Location: sesion_02_01.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Sesión 02-02 - Datos en sesión ordenados y sin repetición
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Almacenamiento de datos en sesión</h1>

  <p>La segunda página comprueba:</p>
  <p>● si se ha escrito algo de texto y ese texto todavía no está guardado, lo guarda en $_SESSION.</p>
  <p>● si se ha pedido borrar todos los nombres, los borra.</p>
  <p>● en todos los casos, vuelve automáticamente a la primera página.</p>
  <p>● si se ha escrito algo de texto, lo guarda en $_SESSION.</p>
  <p>● si se ha pedido borrar todos los nombres, los borra.</p>
  <p>● en todos los casos, vuelve automáticamente a la primera página.</p>

  <?php

  function obtenerValorCampo(string $campo): string{
    if (isset($_REQUEST[$campo])) {
      $valor = trim(htmlspecialchars($_REQUEST[$campo], ENT_QUOTES, "UTF-8"));
    } else {
      $valor = "";
    }

    return $valor;
  }

  $obtenerNombre = obtenerValorCampo("datos");

  $cierreDeSesion = obtenerValorCampo("cerrar");

  if (!$obtenerNombre == "") {
    $_SESSION["datos"][] = $obtenerNombre;
    //Con array_unique hacemos que no se repiten los valores
    $_SESSION["datos"] = array_unique($_SESSION["datos"]);
    //Con sort lo ordenamos alfabéticamente
    sort($_SESSION["datos"]);
  }


  if ($cierreDeSesion == "Cerrar Sesión") {
    //Cerramos la sesión y volvemos a la primera página
    session_destroy();
    header("Location: sesion_02_01.php");
    exit;
  }


  header("Location: sesion_02_01.php");
  ?>

</body>

</html>