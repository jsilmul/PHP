<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <title>
        Sesión 03 - Elimine dibujo
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <h1>Elimine dibujos en el orden indicado</h1>

    <p> ● En esta segunda página se eliminará del primer array el elemento con el índice recibido si es el indicado
        y se redirigirá a la primera página.
    </p>

    <?php
    //Crear sesión
    session_name("eliminar_dibujo");
    //Iniciar sesión
    session_start();

    //Si el array dibujo no existe
    if (!isset($_SESSION["dibujo"])){
        //Redirigimos a la primera página
        header("Location:sesion_03_01.php");
        exit;
    }

    //Funciones
    function obtenerValorCampo(string $campo): string{
        if (isset($_REQUEST[$campo])){
            $valor = trim(htmlspecialchars($_REQUEST[$campo], ENT_QUOTES, "UTF-8"));
        }else{
            $valor = "";
        }

        return $valor;
    }

    //Seleccionamos el dibujo a eliminar
    $eliminado = obtenerValorCampo("eliminado");

    //Eliminar el dibujo recibido con unset
    unset($_SESSION["dibujo"][$eliminado]);

    //Cuando no queden dibujos
    if (!count($_SESSION["dibujo"])) {
        //Destruimos la sesión y se vuelve a crear una nueva sesión en la primera página
        session_destroy();
    }

    //Nos redirigimos a la primera página
    header("Location:sesion_03_01.php");    
    ?>

</body>
</html>