<?php
//Crear sesión
session_name("eliminar_dibujo");
//Iniciar sesión
session_start();

//Si el array dibujo no existe
if (!isset($_SESSION["dibujo"])){
//La definimos
  $_SESSION["sieteDibujos"] = 7;
  for($i = 0; $i < $_SESSION["sieteDibujos"]; $i++){
    $_SESSION["dibujo"][$i] = rand (127789, 127868);
  }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sesión 03 - Elimine dibujo
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

  <h1>Elimine dibujos en el orden indicado</h1>

    <p> Escriba un programa que muestre siete dibujos. Los dibujos serán entidades numéricas del rango 127789 a 127868
        (emojis de alimentos y plantas) y no se pueden repetir. Además se mostrará el dibujo que se quiere eliminar. Al 
        hacer clic en el dibujo que coincida con el de muestra, el dibujo se eliminará. Cuando se elimine el último dibujo,
        se volverán a mostrar siete dibujos para elegir.
    </p>
    <p> ● En esta primera página se mostrarán los dibujos y un dibujo de los mostrados a eliminar. Los números de los dibujos
          se guardarán en un primer array como variable de sesión. Cada dibujo estará incluido en un botón que enviará el índice
          correspondiente al número de dibujo.
    </p>

      <?php
      //Contamos los dibujos que tenemos
      echo "<p>Tenemos $_SESSION[sieteDibujos] dibujos en principio, y ahora quedan " . count($_SESSION["dibujo"]) . " dibujos. <p>";
      //Clickamos en un dibujo para eliminarlo
      echo "<p>Clickamos en un dibujo para eliminarlo.</p>";
      ?>

  <form action="sesion_03_02.php" method="post">
    <p>

      <?php
      foreach($_SESSION["dibujo"] as $indice => $valor) {
        echo "<button name=\"eliminado\"  value=\"$indice\"  style=\"font-size: 700%\">";
        echo "&#$valor";
        echo "</button>";
      }
      ?>

    </p>
  </form>

</body>
</html>