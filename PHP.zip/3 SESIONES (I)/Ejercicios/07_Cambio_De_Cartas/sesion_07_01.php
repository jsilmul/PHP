<?php

   print "<p>Ejercicio incompleto</p>";

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Sesión 07 - Cambio de cartas
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Cambio de cartas</h1>
  <p>La puntuación total es la suma de los valores de las cartas. Las cartas repetidas valen el doble, las repetidas tres veces el triple y las repetidas cuatro veces valen cuatro veces más.</p>

  <p>Puede cambiar hasta cinco cartas. Haga clic en la carta que desee cambiar:</p>
  <form action="sesion_07_02.php" method="post">

    <p>
<?php

     print "<p>Ejercicio incompleto</p>";

?>
    </p>

    <!--Cambios Realizados !-->


    <p><input type="submit" name="accion" value="reiniciar"></p>
  </form>

  
</body>
</html>
