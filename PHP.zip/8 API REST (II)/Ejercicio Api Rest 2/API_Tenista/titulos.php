<?php
/**
 * Ejercicio - API
 *
 * @author Jerónimo Silva Mulero.
*/

  //llamamos a los archivos config.php y funciones.php que están dentro de la carpeta utiles con los codigosHTTP 
  //de los headerJSON, con las funciones de validación y las funciones para trabajar con la bbdd dwes_tarde_tenistas
  require_once("../utiles/config.php");
  require_once("../utiles/funciones.php");

  //usamos la variable $conexion y la función conectarPDO para conectarnos con la bbdd(database)
  $conexion = conectarPDO($database);

  //aquí, en esta variable, almacenamos los datos, los resultados; al principio la declaramos como vacía
  $datos = "";

  // ESCRIBA AQUI EL CÓDIGO PHP NECESARIO


  /*
    Insertar título tenista
  */

  //usamos el método POST porque es un insert, una creación de un registro
  if($_SERVER['REQUEST_METHOD'] == 'POST'){
    //transformamos el json de entrada de datos de los titulos a un array asociativo
    $titulos = json_decode(file_get_contents("php://input"), true);

    //definimos las variables de los años, los id de los tenistas y de los torneos dentro de la variable creada, $titulos
    $anno = $titulos["anno"];
    $tenista_id = $titulos["tenista_id"];
    $torneo_id = $titulos["torneo_id"];


    //con esta select, comprobamos que el tenista exista
    $select = "SELECT * FROM tenistas WHERE id = ?";
    //preparamos la variable $consulta de la select con prepare
    $consulta = $conexion->prepare($select);
    //parámetro del id del tenista con bindParam
    $consulta->bindParam(1, $tenista_id);
    //ejecutamos la consulta
    $consulta->execute();


      //si el resultado de la consulta es menor que 1, cerramos la consulta
      if($consulta->rowCount() < 1){
        $consulta = null;

        //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
        $datos = json_encode(array('mensaje de la consulta' => "Id del tenista inválida, este tenista no existe en la bbdd." ));
        header($headerJSON);
        //CÓDIGO HTTP 404, NOT FOUND
        header($codigosHTTP["404"]);



      //si no...
      }else{
        //cerramos la consulta
        $consulta = null;


        //y con esta select, comprobamos que el torneo exista
        $select = "SELECT * FROM torneos WHERE id = ?";
        //preparamos la variable $consulta de la select con prepare
        $consulta = $conexion->prepare($select);
        //parámetro del id del torneo con bindParam
        $consulta->bindParam(1, $torneo_id);
        //ejecutamos la consulta
        $consulta->execute();


        //si el resultado de la consulta es menor que 1, cerramos la consulta
        if($consulta->rowCount() < 1){
          $consulta = null;

          //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
          $datos = json_encode(array('mensaje de la consulta' => "Id del torneo inválido, este torneo no existe en la bbdd." ));
          header($headerJSON);
          //CÓDIGO HTTP 404, NOT FOUND
          header($codigosHTTP["404"]);


        //si no....
        }else{
            //cerramos la consulta
            $consulta = null;

            //y ahora, con esta nueva select sobre la tabla títulos, comprobamos que el año y el id del torneo existan
            $select = "SELECT anno, torneo_id FROM titulos WHERE anno = ? AND torneo_id = ? ";
            //preparamos la variable $consulta de la select con prepare
            $consulta = $conexion->prepare($select);
            //usamos bindParam para dos de los tres parámetros definidos arriba, cojemos los años y 
            //los ids de los torneos, porque antes ya usamos a los ids de los tenistas
            $consulta->bindParam(1, $anno);
            $consulta->bindParam(2, $torneo_id);
            //y ahora sí, ejecutamos la consulta
            $consulta->execute();


            //si el resultado de la consulta es mayor que 0, cerramos la consulta
            if($consulta->rowCount() > 0){
              $consulta = null;

              //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
              $datos = json_encode(array('mensaje de la consulta' => "Ya hay un tenista que ha ganado ese torneo en ese año." ));
              header($headerJSON);
              //CÓDIGO HTTP 400, BAD REQUEST
              header($codigosHTTP["400"]);

            }else{
              $consulta = null;

              //si todo ha ido bien, hacemos ahora una consulta del tipo $insert(insertar el nuevo titulo)
              //en la insert, metemos los valores en sus respectivos campos, esto es, los años y los ids 
              //de los tenistas y de los torneos
              $insert = "INSERT INTO titulos (anno, tenista_id, torneo_id) VALUES (:annno, :idTenista, :idTorneo)";

              //consulta preparada
              $consulta = $conexion->prepare($insert);
              //usamos bindParam para los tres parámetros definidos arriba, el del año y los ids de tenistas y torneos
              $consulta->bindParam(":annno", $anno);
              $consulta->bindParam(":idTenista", $tenista_id);
              $consulta->bindParam(":idTorneo", $torneo_id);


                //ejecutamos la consulta con try/catch, capturamos la excepción y codificamos a json los datos
                try{
                  //ejecutamos la consulta
                  $consulta->execute();
                  header($headerJSON);
                  //CÓDIGO HTTP 200, OK
                  header($codigosHTTP["200"]);
                  //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje ç
                  $datos = json_encode(array('mensaje de la consulta' => "Titulo dado de alta correctamente."));

                  //se captura la excepción, esto es procedente de la función conectarPDO
                  }catch(PDOException $exception){
                    //y ahora obtenemos el error, esto también viene de conectarPDO
                    $errorDescription = $exception->getMessage();
                    //si se dá este caso, metemos el error en el array
                    $datos = json_encode(array('error' => $errorDescription));
                    header($headerJSON);
                    //CÓDIGO HTTP 500, INTERNAL SERVER ERROR
                    header($codigosHTTP["500"]);

                }

            }

        }

      }

      //cerramos la conexion y pintamos los resultados
			$conexion = null;
      echo $datos;
		exit();
  }


  // ESCRIBA AQUI EL CÓDIGO PHP NECESARIO

//En caso de que ninguna de las opciones anteriores se haya ejecutado
header ($headerJSON);
header ($codigosHTTP["400"]);
echo  $datos;
?>