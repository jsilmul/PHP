<?php
/**
 * Ejercicio - API
 *
 * @author Jerónimo Silva Mulero.
*/

  //llamamos a los archivos config.php y funciones.php que están dentro de la carpeta utiles con los codigosHTTP 
  //de los headerJSON, con las funciones de validación y las funciones para trabajar con la bbdd dwes_tarde_tenistas
  require_once("../utiles/config.php");
  require_once("../utiles/funciones.php");

  //usamos la variable $conexion y la función conectarPDO para conectarnos con la bbdd(database)
  $conexion = conectarPDO($database);

  //aquí, en esta variable, almacenamos los datos, los resultados; al principio la declaramos como vacía
  $datos = "";

  // ESCRIBA AQUI EL CÓDIGO PHP NECESARIO



  /*
    Actualizar una superfice
  */


  //usamos el método PUT porque es una modificación, una actualización de un registro
  if($_SERVER['REQUEST_METHOD'] == 'PUT'){
    //transformamos el json de entrada de datos de las superficies a un array asociativo
    $superficies = json_decode(file_get_contents("php://input"), true);
    //usamos los campos "id" y "nombre" de superficies para sus respectivas variables
    $superficiesId     = $superficies["id"];
    $superficiesNombre = $superficies["nombre"];



    //con esta select comprobamos que el id de superficies exista
    $select = "SELECT * FROM superficies WHERE id = ?";
    //preparamos la variable $consulta de la select con prepare
    $consulta = $conexion->prepare($select);
    //parámetro del id de la superficie con bindParam
    $consulta->bindParam(1, $superficiesId);
    //ejecutamos la consulta
    $consulta->execute();


      //si el resultado de la consulta es mayor que 0, cerramos la consulta
      if($consulta->rowCount() > 0){
        $consulta = null;

        //ahora con una consulta preparada y con la conexion a la bbdd, actualizamos 
        //la tabla con el update, donde el nombre corresponda a tal id 
        $consulta = "UPDATE superficies SET nombre = :nombre WHERE id = :id_superficie ";
        //preparamos la variable $consulta del delete con prepare
        $consulta = $conexion->prepare($consulta);
        //usamos bindParam para los parámetros definidos arriba, el del id y el del nombre
        $consulta->bindParam(":id_superficie", $superficiesId);
        $consulta->bindParam(":nombre",        $superficiesNombre);
        //y ahora sí, ejecutamos la consulta
        $consulta->execute();


          //variable errores
          $errores = $consulta->errorInfo();
          //si la cuenta de los errores...
          if(count($errores)){
            //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
            $datos = json_encode(array('mensaje de la consulta' => "Actualización correcta, superficie modificada." ));
            header($headerJSON);
            //CÓDIGO HTTP 200, OK
            header($codigosHTTP["200"]);
          }

      //si no...
      }else{
        //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
        $datos = json_encode(array('mensaje de la consulta' => "No se encuentra la superficie recibida." ));
        header($headerJSON);
        //CÓDIGO HTTP 400, BAD REQUEST
        header($codigosHTTP["400"]);
      }

      //codificación json de la consulta 
      json_encode($consulta);
      header($headerJSON);


  //si no...    
  }else{
      //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
      $datos = json_encode(array('mensaje de la consulta' => "Error en la ejecución de la consulta de actualización." ));
      header($headerJSON);
      //CÓDIGO HTTP 400, BAD REQUEST
      header($codigosHTTP["400"]);

      //cerramos la conexion y pintamos los resultados
			$conexion = null;
      echo $datos;
		exit();
  }


  // ESCRIBA AQUI EL CÓDIGO PHP NECESARIO

//en caso de que ninguna de las opciones anteriores se haya ejecutado
header ($headerJSON);
header ($codigosHTTP["400"]);
echo $datos;
?>