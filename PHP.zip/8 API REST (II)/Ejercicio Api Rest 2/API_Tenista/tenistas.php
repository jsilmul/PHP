<?php
/**
 * Ejercicio - API 
 *
 * @author Jerónimo Silva Mulero.
*/

  //llamamos a los archivos config.php y funciones.php que están dentro de la carpeta utiles con los codigosHTTP 
  //de los headerJSON, con las funciones de validación y las funciones para trabajar con la bbdd dwes_tarde_tenistas
  require_once("../utiles/config.php");
  require_once("../utiles/funciones.php");

  //usamos la variable $conexion y la función conectarPDO para conectarnos con la bbdd(database)
  $conexion = conectarPDO($database);

  //aquí, en esta variable, almacenamos los datos, los resultados; al principio la declaramos como vacía
  $datos = "";

  // ESCRIBA AQUI EL CÓDIGO PHP NECESARIO
  


  /*
    Datos del tenista y una nueva clave con los titulos que tiene, que es una estructura en la que aparecen los nombres de los títulos agrupados por años
  */

  //usamos el método GET porque es una select, una selección de un registro
  if($_SERVER['REQUEST_METHOD'] == 'GET'){

      //si existe el id del tenista.....
      if(isset($_GET["id"])){
          $idDelTenista = $_GET["id"];

          //selecionamos tenistas t, titulos titu y torneos torn uniendo todas las tablas con los joins
          $select = "SELECT t.id, t.nombre nombretenista, t.apellidos, t.altura, t.anno_nacimiento, titu.anno annotorneo, torn.nombre nombretorneo, torn.ciudad ciudad
                      FROM tenistas t 
                      LEFT JOIN titulos titu
                      ON t.id = titu.tenista_id
                      LEFT JOIN torneos torn
                      ON titu.torneo_id = torn.id
                      WHERE t.id = :id "; 

          //preparamos la variable $consulta de la select con prepare
          $consulta = $conexion->prepare($select);
          //parámetro del id del tenista con bindParam
          $consulta->bindParam(':id', $idDelTenista);
          //ejecutamos la consulta
          $consulta->execute();

          //si el resultado de la consulta es mayor que 0, creamos arrays con el tenista y los titulos
          if($consulta->rowCount()> 0){
              $tenista = [];
              $añoytorneo = [];

              //mientras los titulos del tenista sea igual a el resultado de la consulta anterior
              while($titulosDelTenista = $consulta->fetch(PDO::FETCH_ASSOC)){
                  
                  //si los titulos del tenista es diferente de nulo, rellenamos los arrays añoytorneo y tenista con sus campos
                  if($titulosDelTenista["nombretorneo"] != NULL){

                        $añoytorneo[$titulosDelTenista["annotorneo"]] [] =  [
                                                                              "Torneo" => $titulosDelTenista["nombretorneo"],
                                                                              "Ciudad" => $titulosDelTenista["ciudad"]
                                                                            ];
                  }
                        $tenista =  [
                                      "Id Del Tenista" => $titulosDelTenista["id"],
                                      "Nombre Del Tenista" => $titulosDelTenista["nombretenista"],
                                      "Apellidos Del Tenista" => $titulosDelTenista["apellidos"],
                                      "Altura Del Tenista (en cm)" => $titulosDelTenista["altura"],
                                      "Año De Nacimiento" => $titulosDelTenista["anno_nacimiento"],
                                      "Títulos Separados Por Años" => $añoytorneo
                                    ];

              }

              //resultado de los datos, los cuales lo codificamos con json que metemos en la variable $tenista, mensaje de error y status
              $datos = json_encode($tenista);
              header($headerJSON);
              //CÓDIGO HTTP 200, OK
              header($codigosHTTP["200"]);

          }else{
              //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
              $datos = json_encode(array('mensaje de consulta' => "No se encuentra el tenista recibido."));
              header($headerJSON);
              //CÓDIGO HTTP 404, NOT FOUND
              header($codigosHTTP["404"]);

          }

      }

      //cerramos la conexion y pintamos los resultados
			$conexion = null;

			echo $datos;
			exit();

  }




  /*
    Borrar un tenista
  */

  //usamos el método DELETE porque es una consulta tipo delete, un borrado de un registro
  if($_SERVER['REQUEST_METHOD'] == 'DELETE'){
    //transformamos el json de entrada de datos de los tenistas a un array asociativo
    $tenista=json_decode(file_get_contents("php://input"), true);
    //definimos la variables del id de los tenistas dentro de la variable creada, $tenista
    $tenistaId = $tenista["id"];


    //con esta select, comprobamos que el tenista exista
    $select = "SELECT * FROM tenistas WHERE id = ?";
    //preparamos la variable $consulta de la select con prepare
    $consulta = $conexion->prepare($select);
    //parámetro del id del tenista con bindParam
    $consulta->bindParam(1, $tenistaId);
    //ejecutamos la consulta
    $consulta->execute();



      //si el resultado de la consulta es mayor que 0, cerramos la consulta
      if ($consulta->rowCount() > 0) {
        $consulta = null;

        //borramos en la tabla tenistas donde el id del tenista sea el seleccionado
        $consulta = "DELETE FROM tenistas WHERE id = :tenistaId " ;
        //preparamos la variable $consulta del delete con prepare
        $consulta = $conexion->prepare($consulta);
        //parámetro del id del tenista con bindParam
        $consulta->bindParam(":tenistaId", $tenistaId);
        //ejecutamos la consulta
        $consulta->execute();


            //variable errores
            $errores = $consulta->errorInfo();
            //si la cuenta de los errores...
            if(count($errores)){
              //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
              $datos = json_encode(array('mensaje de la consulta' => "Borrado realizado." ));
              header($headerJSON);
              //CÓDIGO HTTP 200, OK
              header($codigosHTTP["200"]);
            }
      
      //si no....
      }else{
        //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
        $datos = json_encode(array('mensaje de la consulta' => "No se encuentra el tenista recibido." ));
        header($headerJSON);
        //CÓDIGO HTTP 400, BAD REQUEST
        header($codigosHTTP["400"]);
      }

      //codificación json de la consulta 
      json_encode($consulta);
      header($headerJSON);


  //si no...
  }else{
        //datos, los cuales lo codificamos con json, y en el array, lanzamos el mensaje y su status(su número)
        $datos = json_encode(array('mensaje de la consulta' => " Error a la hora de borrar un tenista. " ));
        header($headerJSON);
        //CÓDIGO HTTP 400, BAD REQUEST
        header($codigosHTTP["400"]);


        //cerramos la conexion y pintamos los resultados
        $conexion = null;
        echo $datos;
        exit();

  }


  // ESCRIBA AQUI EL CÓDIGO PHP NECESARIO

//En caso de que ninguna de las opciones anteriores se haya ejecutado
header ($headerJSON);
header ($codigosHTTP["400"]);
echo  $datos;
?>