<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 5 - Eliminar dado
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Eliminar dado</h1>

  <p>Escriba un programa:</p>
  <p>● que muestre primero una tirada de un número de dados al azar entre 1 y 10.</p>
  <p>● que muestre a continuación un dado al azar.</p>
  <p>● que muestre de nuevo la tirada inicial, pero habiendo eliminado de la tirada los dados que coincidan con el dado suelto (si hay alguno).</p>

  <p>Actualice la página para mostrar una nueva tirada.</p>

<?php
$numeros = rand(1, 10);

//guardamos los dados en el array $numeroDados
$numeroDados = [];
for ($i = 0; $i < $numeros; $i++) {
    $numeroDados[$i] = rand(1, 6);
}

//pintamos las imágenes de los dados 
if ($numeros == 1) {
    echo "<p>Ha salido $numeros dado</p>";
} else {
    echo "<p>Han salido $numeros dados</p>";
}

foreach ($numeroDados as $dado) {
  echo "<img src= \"img/$dado.svg\"   alt=\"$dado\"   width=\"100\"   height=\"100\">";
}


//guardamos el dado a eliminar
$dadoEliminado = rand(1, 6);

//pintamos el dado a eliminar
echo "<p>Dado eliminado</p>";
echo "<img src= \"img/$dadoEliminado.svg\"   alt=\"$dadoEliminado\"   width=\"100\"   height=\"100\">";


//eliminamos el dado del array
for ($i = 0; $i < $numeros; $i++) {
    if ($numeroDados[$i] == $dadoEliminado) {
        unset($numeroDados[$i]);
    }
}

//pintamos las imágenes de los dados que quedan tras la eliminación
echo "<p>Dados que nos quedan</p>";

if (count($numeroDados) == 0) {
    echo "<p>No queda ningún dado</p>\n";
  }else{
    foreach ($numeroDados as $dado) {
      echo "<img src= \"img/$dado.svg\"   alt=\"$dado\"   width=\"100\"   height=\"100\">";
  }
}
?>

</body>
</html>