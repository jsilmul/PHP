<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 7 - Contar cartas
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Contar cartas</h1>

  <p>Escriba un programa:</p>
  <p>● que muestre primero un grupo de entre 7 y 20 cartas de corazones numeradas del 1 al 10 al azar (carpeta cartas).</p>
  <p>● que indique cuántas veces ha aparecido cada una de las cartas.</p>

  <p>Actualice la página para mostrar un nuevo grupo de valores de cartas de corazones.</p>

<?php

$cartas = rand(7, 20);

//guardamos los valores de las cartas en el array $valoresContarCartas
$valoresContarCartas = [];
for ($i = 0; $i < $cartas ; $i++) {
    $valoresContarCartas[$i] = rand(1, 10);
}

//pintamos las imágenes de las cartas 
  echo "<br><strong>$cartas cartas de corazones</strong><br>";

foreach ($valoresContarCartas as $imagen) {
  echo "<img src= \"cartas/c$imagen.svg\"   alt=\"$imagen\"   width=\"90\"   height=\"130\">";
}

//creamos una nueva variable llamada arrayContador para indicar cuantas veces aparece 
//cada una de las cartas con la función array_count_values($arrayContador), esta función
//cuenta cuántos valores hay de cada valor en un array. El array devuelto tiene como índices
//los valores del array original y como valores la cantidad de veces que aparece el valor.
$arrayContador = array_count_values($valoresContarCartas);
echo "<br></br>";

echo "<strong>Conteo</strong>";
echo "<br></br>";


foreach ($arrayContador as $cartanueva => $veces) {
  echo "<strong>$veces - </strong> <img src= \"cartas/c$cartanueva.svg\"   alt=\"$cartanueva\"   width=\"60\"   height=\"120\"></br>";
}

?>

</body>
</html>