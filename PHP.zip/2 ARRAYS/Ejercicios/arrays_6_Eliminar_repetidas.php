<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 6 - Eliminar valores repetidos
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Eliminar valores repetidos</h1>

  <p>Escriba un programa:</p>
  <p>● que muestre primero un grupo de entre 5 y 15 cartas de corazones numeradas del 1 al 10 al azar (carpeta cartas).</p>
  <p>● que muestre de nuevo el grupo inicial, pero habiendo eliminado del grupo los valores repetidos.</p>

  <p>Actualice la página para mostrar un nuevo grupo de valores de cartas de corazones.</p>

<?php

$valores = rand(5, 15);

//guardamos los valores de las cartas en el array $valoresCartas
$valoresCartas = [];
for ($i = 0; $i < $valores; $i++) {
    $valoresCartas[$i] = rand(1, 10);
}

//pintamos las imágenes de las cartas 
echo "<br><strong>Entre estas $valores cartas corazones....</strong><br>";


foreach ($valoresCartas as $carta) {
  echo "<img src= \"cartas/c$carta.svg\"   alt=\"$carta\"   width=\"110\"   height=\"150\">";
}


//creamos una nueva variable para eliminar los valores repetidos llamada $arraySinValoresRepetidos
//con este método conservamos los valores originales de $valoresCartas, en el caso de que tengamos 
//que utilizarlo más adelante en otro u otros apartados diferente del ejercicio

//$arraySinValoresRepetidos = array_unique($valoresCartas);
//echo "<pre>";
//print_r($arraySinValoresRepetidos);
//echo "</pre>";


//sin embargo con este método, no necesitamos crear una nueva variable, pero, una vez que se 
//ejecuta, vamos a perder los valores originales del array $valoresCartas. A partir de ahora,
//no podríamos usar la información original de dicho array
$valoresCartas = array_unique($valoresCartas);
echo "<br></br>";


//creamos una nueva variable llamada $cartasRestantes para pintar las cartas que nos quedan del
//array original, el $valoresCartas con la función count, que nos permite contar los valores de 
//dicho arrray
$cartasRestantes = count($valoresCartas);

if ($cartasRestantes == 1) {
  echo "<br><strong>........hay $cartasRestantes carta corazón distinta</strong></br>";
} else {
  echo "<br><strong>........hay $cartasRestantes cartas corazones distintas</strong></br>";
}


//pintamos los valores de las cartas restantes
foreach ($valoresCartas as $cartanueva) {
  echo "<img src= \"cartas/c$cartanueva.svg\"   alt=\"$cartanueva\"   width=\"110\"   height=\"150\">";
}
?>

</body>
</html>