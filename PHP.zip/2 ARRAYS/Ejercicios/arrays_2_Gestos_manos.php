<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 2 - Gestos manos
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Gestos manos</h1>

  <p>Actualice la página para mostrar un nuevo dibujo.</p>

<?php

  $gesto = [128070, 128071, 128072, 128073, 128074, 128075, 128076, 128077, 128078, 128079, 128080, 128133, 128170, 
            128400, 128405, 128406, 128588, 128591, 129295, 129304, 129305, 129306, 129307, 129308, 129310, 129311, 129330];

  $gestoAleatorio = rand(0,count ($gesto)-1);

  $tonoDePiel = rand(127995, 127999);

  echo " <p><span style=\"font-size: 6em\">&#$gesto[$gestoAleatorio];&#$tonoDePiel</span></p>\n";


?>

</body>
</html>
