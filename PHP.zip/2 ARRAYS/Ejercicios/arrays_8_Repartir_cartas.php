<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 8 - Repartir cartas
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Repartir cartas</h1>

  <p>Escriba un programa:</p>
  <p>● que muestre un número par de cartas de corazones, entre 4 y 10, al azar y no repetidas.</p>
  <p>● que reparta las cartas entre dos jugadores, al azar.</p>

  <p>Actualice la página para mostrar un nuevo reparto de cartas de corazones.</p>


<?php
//$numeroCartas es el número de cartas que se reparte a cada jugador, así que 
//multiplicamos $numeroCartas cartas por 2, por que son dos jugadores. 
$numeroCartas= rand(2, 5);

//además, se guardan los números o valores de las cartas en el array $cartasTotales
$cartasTotales = [];

for ($i = 0; $i < $numeroCartas * 2; $i++) {
  $valorCarta = rand(1, 10);

  while (in_array($valorCarta, $cartasTotales)) {
    $valorCarta = rand(1,10);
    } 
   $cartasTotales[$i] = $valorCarta;
  }


//pintamos las imágenes de las cartas que nos salen desde la carpeta cartas
echo "<strong>Las " .  $numeroCartas * 2 . " cartas a repartir</strong>";
echo "<br></br>";

foreach ($cartasTotales as $cards) {
    echo "<img src=\"cartas/c$cards.svg\"  alt=\"$cards\"   width=\"90\"  height=\"130\" >";
}
echo "<br></br>";


//se reparten los valores de las cartas con la función shuffle
shuffle($cartasTotales);


//se crea un array llamado $cartasJugador1 con las $valoresCartas de las primeras cartas(jugador 1)
$cartasJugador1 = [];
for ($i = 0; $i < $numeroCartas; $i++) {
    $cartasJugador1[] = $cartasTotales[$i];
}

//se crea otro array llamado $cartasJugador2 con los $valoresCartas de las siguentes cartas(jugador 2)
$cartasJugador2 = [];
for ($i = 0; $i < $numeroCartas; $i++) {
    $cartasJugador2[] = $cartasTotales[$i+ $numeroCartas];
}



//pintamos las imágenes de las cartas del jugador 1
echo "<strong>Las $numeroCartas cartas del jugador 1 son...</strong>";
echo "<br></br>";

foreach ($cartasJugador1 as $cards) {
    echo "<img src=\"cartas/c$cards.svg\"  alt=\"$cards\"  width=\"90\"   height=\"130\" >";
}
echo "<br></br>";



//pintamos las imágenes de las cartas del jugador 2
echo "<strong>Y las $numeroCartas cartas del jugador 2 son...</strong>";
echo "<br></br>";

foreach ($cartasJugador2 as $cards) {
    echo "<img src=\"cartas/c$cards.svg\"  alt=\"$cards\"  width=\"90\"   height=\"130\" >";
}


?>

</body>
</html>