<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 4 - Partida dados
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Partida dados</h1>

  <p>Escriba un programa que enfrente a dos jugadores tirando una serie de dados al azar entre 3 y 9 e indique el resultado. 
    Los dados se comparan en orden (el primero con el primero, el segundo con el segundo, etc.) y gana el jugador que obtenga 
    el número más alto.</p>

  <p>Mostrar un resumen con cuántas veces ha ganado cada jugador y en conjunto qué jugador ha ganado.</p>

  <p>Actualice la página para mostrar una nueva partida de dados.</p>

<?php
$numero = rand(2, 7);
echo "<p>Jugador 1</p>";

//se guardan los dados del jugador 1 en el array $jugador1
$jugador1 = [];
for ($i = 0; $i < $numero; $i++) {
    $jugador1[$i] = rand(1, 6);
}

//pintamos los resultados del jugador 1
foreach ($jugador1 as $dado) {
    echo "<img src=\"img/$dado.svg\"  alt=\"$dado\"  width=\"120\"  height=\"120\">";
}


echo "<p>Jugador 2</p>";

//se guardan los dados del jugador 2 en el array $jugador2
$jugador2 = [];
for ($i = 0; $i < $numero; $i++) {
    $jugador2[$i] = rand(1, 6);
}

//pintamos los resultados del jugador 2
foreach ($jugador2 as $dado) {
    echo "<img src=\"img/$dado.svg\"  alt=\"$dado\"   width=\"120\"   height=\"120\">";
}


//usamos los contadores $jugador1Gana, $jugador2Gana y $hanEmpatado para ver los empates y para ver cuántas partidas ganado cada jugador
echo "<p>Estadísticas</p>";

$jugador1Gana = 0;
$jugador2Gana = 0;
$hanEmpatado = 0;

for ($i = 0; $i < $numero; $i++) {
    if ($jugador1[$i] > $jugador2[$i]) {
        $jugador1Gana++;
    } elseif ($jugador1[$i] < $jugador2[$i]) {
        $jugador2Gana++;
    } else {
        $hanEmpatado++;
    }
}

//mostramos cuántas partidas ha ganado cada jugador
echo "<p>El jugador 1 ha ganado $jugador1Gana";
echo $jugador1Gana != 1 ? "veces" : "vez";
echo ", el jugador 2 ha ganado $jugador2Gana";
echo $jugador2Gana != 1 ? "veces" : "vez";
echo " y ha habido $hanEmpatado";
echo $hanEmpatado != 1 ? "empates" : "empate";


//resultado final
if ($jugador1Gana > $jugador2Gana) {
    echo "<p>En total, ha ganado el jugador 1.</p>";
} elseif ($jugador1Gana < $jugador2Gana) {
    echo "<p>En total, ha ganado el jugador 2.</p>";
} else {
    echo "<p>Ningún jugador ha ganado más partidas que el otro, en total, han empatado.</p>";
}
?>

</body>
</html>