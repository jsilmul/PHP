<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 1 - Número a letras
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Número a letras</h1>

  <p>Escriba un programa que muestre una tirada de dado al azar y escriba en letras el valor obtenido.</p>

  <p>Actualice la página para mostrar una nueva tirada.</p>

<?php
  $valorDeDado = rand(1,6);
  
  $tirada = [ 1 => "uno", 
              2 => "dos", 
              3=> "tres", 
              4 => "cuatro",
              5 => "cinco", 
              6 => "seis"];

  echo "<img src=\"img/$valorDeDado.svg\"   alt=\"$valorDeDado\" width=\"120\"  height=\"120\"    >";

  echo "<p>Has sacado un $valorDeDado</p>"    
?>

</body>
</html>
