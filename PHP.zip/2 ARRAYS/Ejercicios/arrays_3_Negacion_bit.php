<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Matrices 3 - Negación de bits
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Negación de bits</h1>

  <p>Actualice la página para mostrar una secuencia aleatoria de bits y su complementaria.</p>

<?php

//creamos la variable con el número de bits que nos pide el enunciado, en este caso 10
$secuencia = 10;

//creamos el array vacío de secuencia de bits aleatorios
$arrayBits = [];

//rellenanos el array con el for
for ($i = 0; $i < $secuencia; $i++) {
    $arrayBits[$i] = rand(0, 1);
}

//mostramos los bits aleatorios
echo "  <pre style=\"font-size: 300%;\">\n";
echo "A: ";

//recorremos el array con el foreach y lo pintamos con el echo
foreach ($arrayBits as $bits) {
    echo "$bits ";
}

//creamos un salto de línea para que no se junten las dos secuencias
echo "\n";


//creamos el segundo array, vacío también, con la secuencia de bits aleatorios complementarios
$arrayBitsComplementarios = [];

//rellenanos el array con el for
for ($i = 0; $i < $secuencia; $i++) {
    $arrayBitsComplementarios[$i] = $arrayBits[$i] == 1 ? 0 : 1;
}

//mostramos los valores complementarios
echo "<span style=\"text-decoration: overline\">A</span>: ";

//recorremos el array con el foreach y lo pintamos con el echo
foreach ($arrayBitsComplementarios as $bits) {
    echo "$bits ";
}
?>
</body>
</html>