<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    for 3 - Dado mínimo
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>

<h1>Dado mínimo</h1>

<p>Escriba un programa que cada vez que se ejecute muestre la tirada de entre 1 y 10 dados al azar y diga el valor mínimo obtenido.</p>

<p>Actualice la página para mostrar una nueva tirada.</p>

<?php
$numeroDeDados = rand(1,10);
echo "<p>El número de dados es: $numeroDeDados</p>";

$valorMinimoObtenido = 7;
for($i = 0; $i < $numeroDeDados; $i++){
    $tirada = rand(1,6);
    echo "<img src=\"img/$tirada.svg\"   alt=\"$tirada\" width=\"120\"  height=\"120\"    >";

    if ($tirada < $valorMinimoObtenido){
        $valorMinimoObtenido = $tirada;
    }

}

echo "<p>El valor mínimo obtenido es: $valorMinimoObtenido</p>";

?>

</body>
</html>