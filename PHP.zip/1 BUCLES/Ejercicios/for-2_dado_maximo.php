<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    for 2 - Dado máximo
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
<h1>Dado máximo</h1>

<p>Escriba un programa que cada vez que se ejecute muestre la tirada de entre 1 y 10 dados al azar y diga el valor máximo obtenido.</p>

<p>Actualice la página para mostrar una nueva tirada.</p>

<?php

$numeroDeDados = rand(1,10);
echo "<p>El número de dados es: $numeroDeDados</p>";

$valorMaximoObtenido = 0;
for($i = 0; $i < $numeroDeDados; $i++){
    $tirada = rand(1,6);
    echo " <img src= \"img/$tirada.svg\" alt=\"$tirada\" width=\"120\" height=\"120\">";

    if($tirada > $valorMaximoObtenido) {
        $valorMaximoObtenido = $tirada;
    }

}

echo "<p>El valor máximo obtenido es: $valorMaximoObtenido</p>";

?>

</body>
</html>
