<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    for 5 - Contar dados máximos
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
<h1>Contar dados máximos</h1>

<p>Escriba un programa que cada vez que se ejecute muestre la tirada de entre 1 y 10 dados al azar y diga el valor máximo obtenido y el número de veces que se ha obtenido.</p>

<p>Actualice la página para mostrar una nueva tirada.</p>

<?php
$numeroDeDados = rand(1,10);
echo "<p>El número de dados ha sido: $numeroDeDados</p>";


$valorMaximoObtenido = 0;
$veces = 0;

for($i = 0; $i < $numeroDeDados; $i++){
    $tirada = rand(1,6);
    echo " <img src= \"img/$tirada.svg\" alt=\"$tirada\" width=\"140\" height=\"140\">";

    if($tirada > $valorMaximoObtenido){
        $valorMaximoObtenido = $tirada;
        $veces = 1;
    }elseif($valorMaximoObtenido == $tirada){
        $veces++;
    }
}
echo "<p>El valor máximo obtenido es: $valorMaximoObtenido</p>";
echo "<p>Dicho valor máximo obtenido ha salido: $veces veces</p>";


?>


</body>
</html>