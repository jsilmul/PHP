<?php
//nombramos la sesión
session_name("ejercicio2");
//iniciamos la sesión
session_start();
?>


<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Introducir Edad
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>EDAD</h1>

  <?php
  //  **** AQUÍ TU CÓDIGO PHP ****  //

  //si ya existe la edad introducida, lo indicamos
  if (isset($_SESSION["edad"])) {
    echo "<p>Ya se ha escrito la edad: $_SESSION[edad] </p>";
  }
  ?>

  <!--esta acción que nos lleva a el archivo edad2.php-->
  <form action="edad2.php" method="get">

    <p>Escribe una edad:</p>

    <?php
    //si existe errorEdad, salta el error 
    if (isset($_SESSION["errorEdad"])) {
      echo "<span class=\"error\">$_SESSION[errorEdad]</span></p>";
      //si no, se recoge la edad
    } else {
      echo "<p>Edad: <input type=\"text\" name=\"edad\" size=\"10\" maxlength=\"200\"></p>";
    }
    ?>



    <p>
      <input type="submit" value="Guardar">
      <input type="reset" value="Borrar">
    </p>
  </form>

  <p><a href="index.php">Volver al inicio.</a></p>

</body>

</html>