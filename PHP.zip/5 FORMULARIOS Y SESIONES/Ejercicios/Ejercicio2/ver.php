<?php
//nombramos la sesión
session_name("ejercicio2");
//iniciamos la sesión
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>
    Ver Ficha
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>FICHA</h1>

<?php

//  **** AQUÍ TU CÓDIGO PHP ****  //


if (!isset($_SESSION["nombres"]) & !isset($_SESSION["edad"])) {
  echo "<p>Usted no ha escrito ningún nombre ni ha indicado la edad.</p>";
  
  }elseif (isset($_SESSION["nombres"]) & !isset($_SESSION["edad"])) {
      echo "<p>Usted sólo ha escrito que su nombre es $_SESSION[nombres].</p>";

  }elseif (!isset($_SESSION["nombres"]) & isset($_SESSION["edad"])) {
      echo "<p>Usted sólo ha escrito que tiene $_SESSION[edad] años.</p>";

  }else{
      echo "<p><strong><font color= \"orange\">Tu nombre es <strong>$_SESSION[nombres]</strong> y tienes <strong>$_SESSION[edad] años.</font></strong></p>";
} 

?>

  <p><a href="index.php">Volver al inicio.</a></p>

</body>
</html>
