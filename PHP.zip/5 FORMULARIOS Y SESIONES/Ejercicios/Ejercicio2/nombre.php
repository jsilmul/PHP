<?php
//nombramos la sesión
session_name("ejercicio2");
//iniciamos la sesión
session_start();
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Introducir Nombre
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>NOMBRE</h1>

  <?php
  //  **** AQUÍ TU CÓDIGO PHP ****  //

  //si ya existe el nombre introducido, lo indicamos
  if (isset($_SESSION["nombres"])) {
    echo "<p>Ya se ha escrito este nombre: $_SESSION[nombres] </p>";
  }
  ?>

  <!--esta acción que nos lleva a el archivo nombre2.php-->
  <form action="nombre2.php" method="get">

    <p>Escribe un nombre:</p>


    <?php

    //si existe errorNombres, salta el error 
    if (isset($_SESSION["errorNombres"])) {
      echo "<span class=\"error\">$_SESSION[errorNombres]</span></p>";
      //si no, se recoge el nombre
    } else {
      echo "<p>Nombre: <input type=\"text\" name=\"nombres\" size=\"15\" maxlength=\"15\"></p>";
    }
    ?>


    <p>
      <input type="submit" value="Guardar">
      <input type="reset" value="Borrar">
    </p>

  </form>

  <p><a href="index.php">Volver al inicio.</a></p>

</body>

</html>