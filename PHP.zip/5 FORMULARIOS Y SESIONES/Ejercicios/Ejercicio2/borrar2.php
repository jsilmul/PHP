<?php

//nombramos la sesión
session_name("ejercicio2");

//iniciamos la sesión
session_start();



$accion = $_REQUEST["borrar"];

//si le decimos que si, osea, el value 1
if ($accion == 1){
        //elimina las variables de la sesión, la destruye y te redirige a la página del index
        session_destroy();
        header("Location:index.php");
    //si no, osea, el tro value, el value 2 
    }else{
        //nos lleva al index sin hacer nada, osea, sin borrar el nombre y la edad
        header("Location:index.php");
}


?>