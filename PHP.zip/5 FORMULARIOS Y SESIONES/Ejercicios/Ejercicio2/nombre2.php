<?php
  //nombramos la sesión
  session_name("ejercicio2");
  //iniciamos la sesión
  session_start();
  //llamamos al archivo validaciones.php
  require_once "validaciones.php";




  //  **** AQUÍ TU CÓDIGO PHP ****  //

  $nombres = obtenerValorCampo("nombres");

  //si la variable $nombres está vacía o es un número
  if ($nombres == "" ||  is_numeric($nombres) ||  !validarCadenaSinNumero($nombres) ||  obtenerValorCampo($nombres) ) {
    //lanza el error de que no hay nombres introducidos o esos nombres son números
    $_SESSION["errorNombres"] = "El nombre no puede estar vacío y/o no debe ser un número; debes volver al inicio, borrar la información y rellenar ambos campos correctamente";
    //y te devuelve al archivo anterior, a nombre.php
    header("Location:nombre.php");
    exit;
  } else {
    //si no, borra el errorNombres
    unset($_SESSION["errorNombres"]);
    //y se iguala $nombres a $_SESSION["nombres"]
    $_SESSION["nombres"] = $nombres;
    //por último te lleva al archivo inicial, el index
    header("Location:index.php");
    exit;
  }

?>