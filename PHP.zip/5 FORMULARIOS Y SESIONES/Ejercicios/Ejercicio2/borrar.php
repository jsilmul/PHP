<?php
//nombramos la sesión
session_name("ejercicio2");
//iniciamos la sesión
session_start();
?>



<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Borrado de Datos
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>


<body>
  <h1>Datos Borrados</h1>

  <?php

  //con get, vamos al archivo borrar2.php
  echo "<form action=  \"borrar2.php\"  method=\"get\">";

  //párrafo para preguntar 
  echo "<p> ¿Está seguro de borrar los datos? </p>";

  //botón de radio para sí
  echo "<label> <input type=  \"radio\"    name=  \"borrar\"    value= \"1\"> Sí </label> <br>";

  //botón de radio para no
  echo "<label> <input type=  \"radio\"    name=  \"borrar\"    value= \"2\"> No </label> <br>";

  //botón submit para enviar
  echo "<input type=  \"submit\"    value= \"Enviar\">";

  ?>

</body>

</html>