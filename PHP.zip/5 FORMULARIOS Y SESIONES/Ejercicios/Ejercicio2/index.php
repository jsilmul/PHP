<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Nombre y edad
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Creación de Ficha</h1>

  <p>Elija una opción:</p>

  <ul>
    <li><a href="nombre.php">Escribir su nombre</a></li>
    <li><a href="edad.php">Escribir su edad</a></li>
    <li><a href="ver.php">Ver Ficha</a></li>
    <li><a href="borrar.php">Borrar la información</a></li>
  </ul>

</body>

</html>