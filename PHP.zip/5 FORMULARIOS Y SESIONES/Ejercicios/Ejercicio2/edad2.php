<?php
  //nombramos la sesión
  session_name("ejercicio2");
  //iniciamos la sesión
  session_start();
  //llamamos al archivo validaciones.php
  require_once "validaciones.php";



  
  //  **** AQUÍ TU CÓDIGO PHP ****  //

  $edad = obtenerValorCampo("edad");
  //validar_entero_limites("edad", 0, 200);

  //si la variable $edad está vacía o no es número, y dicho número debes estar entre 18 y 100
  if ($edad == "" ||  !is_numeric($edad) || $edad < 18 || $edad > 100) {
    //lanza el error de que no hay nada introducido o lo que se ha introducido no son números
    $_SESSION["errorEdad"] = "La edad no puede estar vacía y/o debe ser un número, el cual debe estar entre 18 y 100; debes volver al inicio, borrar la información y rellenar ambos campos correctamente.";
    //y te devuelve al archivo anterior, a edad.php
    header("Location:edad.php");
    exit;
  } else {
    //si no, borra el errorEdad
    unset($_SESSION["errorEdad"]);
    //y se iguala $edad a $_SESSION["edad"]
    $_SESSION["edad"] = $edad;
    //por último te lleva al archivo inicial, el index
    header("Location:index.php");
    exit;
  }

?>