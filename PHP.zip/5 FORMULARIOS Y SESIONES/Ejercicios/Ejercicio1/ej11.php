<?php
//nombramos la sesión
session_name("ejercicio1");
//iniciamos la sesión    
session_start();
//metemos el archivo de validaciones
require_once("validaciones.php");


//miramos si las variables de la sesión están defininidas o no están definidas con un bucle if

//si....
if
//no existen ["dados"] 
(!isset($_SESSION["dados"]) 
//o no existe ["dado1"]
|| !isset($_SESSION["dado1"]) 
//o no existe ["dado2"]
|| !isset($_SESSION["dado2"])
//o no existe ["dado3"]
|| !isset($_SESSION["dado3"])
//o no existe ["finDeBucle"] 
|| !isset($_SESSION["finDeBucle"])
//o no existe ["intento"]
|| !isset($_SESSION["intento"]) 
//o no existe ["trio"]
|| !isset($_SESSION["trio"])) 
//inicializamos la funcion que inicia las variables de los  dados
{definicionDeDados();}
?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <title>
    Trio de dados
  </title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
  <h1>Trío de dados</h1>

  <form action="ej12.php" method="post">
    <p>

    <?php

      // **COMPLETAR EL CÓDIGO PHP**

      //variable $finDeBucle que incluye el fiinal del juego, cuando se llega a el trio
      $finDeBucle = $_SESSION["finDeBucle"];
      
      //empezamos con el párrafo de la tirada
      echo "Tirada:<p>";
       
      
      //pintamos los dados con echo    
      echo "<img src=   \"img/". $_SESSION['dado1']  .".svg\"    height=  \"120\"     width=  \"120\"   >";
      echo "<img src=   \"img/". $_SESSION['dado2']  .".svg\"    height=  \"120\"     width=  \"120\"   >";
      echo "<img src=   \"img/". $_SESSION['dado3']  .".svg\"    height=  \"120\"     width=  \"120\"   >";
          
      //acabamos con el párrafo de la tirada
      echo "</p>";



      //si el trio es menor de 13, ganas, si no, pierdes
      if($finDeBucle){
          if($_SESSION['trio']<13){
            echo " <strong><font color= \"green\"> Has conseguido un trío de dados en la tirada número ".$_SESSION['trio'].", por tanto, HAS GANADO </font></strong>";
          }else{
            echo " <strong><font color= \"red\">   Has conseguido un trío de dados en la tirada número ".$_SESSION['trio'].", por tanto, HAS PERDIDO (mayor de 12) </font></strong>";
          }
            echo "<p> <button type= \"submit\"   name= \"accion\"   value= \"comenzar\" > Reiniciar </button> </p>";
        
        exit();
      }


      //submit para cambiar el dado 1, 2 o 3 
      echo "<p> <button type=   \"submit\"    name=\"accion\"    value= \"1\" > Modificar Dado 1 </button>";
      echo "<button type=   \"submit\"    name=\"accion\"    value= \"2\" > Modificar Dado 2</button>";
      echo "<button type=   \"submit\"    name=\"accion\"    value= \"3\" > Modificar Dado 3</button></p>";
      

      //número de intentos
      print "<p>Número de intentos: ".$_SESSION['intento']."</p>";
      
      //y otro submit para reiniciar el juego
      echo "<p> <button type= \"submit\"    name= \"accion\"    value= \"comenzar\"> Reiniciar </button> </p>";
     
    ?>

  </form>
</body>

</html>