<?php
//nombramos la sesión
session_name("ejercicio1");
//iniciamos la sesión    
session_start();
//metemos el archivo de validaciones
require_once("validaciones.php");


//con $accion y obtenerValorCampo obtenemos losdatos
$accion = obtenerValorCampo("accion");

//inicializimos $finDeBucle como falso
$finDeBucle = false;


//si $accion tiene el value comenzar, comenzamos el juego
if ($accion == "comenzar") {
    //e inicializamos las variables de los dados
    definicionDeDados();
    
    //con una serie de elseifs anidados, usamos contadores para cada uno de los dados, el 1, 2 y el 3
    }elseif($accion == 1){
        $_SESSION["dado1"] = rand(1,6);
        $_SESSION["intento"]++;

    }elseif($accion == 2){
        $_SESSION["dado2"] = rand(1,6);
        $_SESSION["intento"]++;
    
    }elseif($accion == 3){
        $_SESSION["dado3"] = rand(1,6);
        $_SESSION["intento"]++;
    }
    


    //variables $dado1, $dado2 y $dado3 que encierran los valores de cada dado
    $dado1 = $_SESSION["dado1"]; $dado2 = $_SESSION["dado2"]; $dado3 = $_SESSION["dado3"];


    //sin $dado1 es igual a $dado2 y $dado1 es igual a $dado3
    if ($dado1 == $dado2  &&  $dado1 == $dado3){
        //cambiamos $finDeBucla a verdadero que estaba en falso desde la línea 14
        $finDeBucle=true;


        //e igualamos el trio con el numero de intentos realizados
        $_SESSION["finDeBucle"] = $finDeBucle; $_SESSION["trio"] = $_SESSION["intento"];
    }   


//header hacia la página de inicio
header("Location: ej11.php");
?>